SET session_replication_role = replica;

--
-- PostgreSQL database dump
--

-- \restrict EJ2anmLKwjs83Ins2TVm0tLMg36ltL0zgvfImsvDbdJH1BQe9hIC3BRhmKUcLbL

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
00000000-0000-0000-0000-000000000000	ee2a4422-b096-47b7-bfbb-541217503bf7	authenticated	authenticated	adjanio@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "adjanio@cevd.com", "perfil": "User", "full_name": "Adjanio"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4db36368-05b1-4fd4-ac13-c8a8c06ba5f9	authenticated	authenticated	wesley@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "wesley@cevd.com", "perfil": "User", "full_name": "Wesley"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e49d2c9b-6744-497c-bb61-b58abcb6c7e5	authenticated	authenticated	yokennan@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "yokennan@cevd.com", "perfil": "User", "full_name": "Yokennan"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c7d4a12b-47a4-498d-baf0-1ce0a0212bb2	authenticated	authenticated	v.rodrigues@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "v.rodrigues@cevd.com", "perfil": "User", "full_name": "V. Rodrigues"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	2577d100-73c8-4579-9de2-4e76818a027e	authenticated	authenticated	v.mesquita@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "v.mesquita@cevd.com", "perfil": "User", "full_name": "V. Mesquita"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	24d79386-6eea-4478-8f2c-5611192b7a0c	authenticated	authenticated	aleane@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "aleane@cevd.com", "perfil": "User", "full_name": "Aleane"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	18c7dd1b-8347-443d-b439-2bb8579b5386	authenticated	authenticated	cilene@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "cilene@cevd.com", "perfil": "User", "full_name": "Cilene"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	authenticated	authenticated	dany@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "dany@cevd.com", "perfil": "User", "full_name": "Dany"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a1d9f814-46e4-48d4-8262-b3fce5cb0fd6	authenticated	authenticated	eduardo@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "eduardo@cevd.com", "perfil": "User", "full_name": "Eduardo"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b64a4caa-b645-414e-a213-d3076076922b	authenticated	authenticated	felipe@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "felipe@cevd.com", "perfil": "Advanced", "full_name": "Felipe"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	96d801f5-58e6-444f-9416-d6817bb47042	authenticated	authenticated	gabriel@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "gabriel@cevd.com", "perfil": "User", "full_name": "Gabriel"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ec5dc436-f243-49d2-a66b-c114b6811ea0	authenticated	authenticated	guilherme@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "guilherme@cevd.com", "perfil": "User", "full_name": "Guilherme"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e7fae8f4-1411-459b-af01-0eefdaa7e57c	authenticated	authenticated	ana.clara@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "ana.clara@cevd.com", "perfil": "User", "full_name": "Ana Clara"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6993a591-8905-49e7-a35e-3eda54081713	authenticated	authenticated	henrique@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "henrique@cevd.com", "perfil": "User", "full_name": "Henrique"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	dff6aff0-a4ac-4141-bda1-8e8ffa04cfff	authenticated	authenticated	isis@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "isis@cevd.com", "perfil": "User", "full_name": "Isis"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	414350c9-e858-4dee-85e4-a93c3a05bced	authenticated	authenticated	jessé@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "jessé@cevd.com", "perfil": "Advanced", "full_name": "Jessé"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	7e79b82c-fc1f-4322-8200-9c371805abe3	authenticated	authenticated	kaká@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "kaká@cevd.com", "perfil": "User", "full_name": "Kaká"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	03a18d33-f884-43a5-a579-162578daac5a	authenticated	authenticated	lucas@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "lucas@cevd.com", "perfil": "Advanced", "full_name": "Lucas"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1563eb41-f8ad-4ff8-a141-778e4e73a288	authenticated	authenticated	marcos@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "marcos@cevd.com", "perfil": "User", "full_name": "Marcos"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	04696c14-57f5-4492-a09d-91a4bd2aea80	authenticated	authenticated	marilei@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "marilei@cevd.com", "perfil": "User", "full_name": "Marilei"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	35be7e54-5d03-4e92-9304-abe4ca3885e8	authenticated	authenticated	mikeias@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "mikeias@cevd.com", "perfil": "Advanced", "full_name": "Mikeias"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	51306dad-b8e0-46b4-aaa4-24510690a705	authenticated	authenticated	naira@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "naira@cevd.com", "perfil": "User", "full_name": "Naira"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	332c48aa-eb34-452a-971e-5f3dbafad987	authenticated	authenticated	nayane@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "nayane@cevd.com", "perfil": "User", "full_name": "Nayane"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	2ee9bbd2-f0e0-4e42-b7ca-a1eba002783b	authenticated	authenticated	rosy@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "rosy@cevd.com", "perfil": "User", "full_name": "Rosy"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	49eee164-7639-4d09-9a19-997955cef4d5	authenticated	authenticated	veronica@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "veronica@cevd.com", "perfil": "User", "full_name": "Veronica"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4b543930-107b-4580-b00f-958769fa4400	authenticated	authenticated	anne.gabrielly@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-01-28 18:47:37.482127+00	{"provider": "email", "providers": ["email"]}	{"email": "anne.gabrielly@cevd.com", "perfil": "User", "full_name": "Anne Gabrielly"}	\N	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	23d2d224-8f94-4e4f-ab13-7e8868e20611	authenticated	authenticated	jhordan@cevd.com	$2a$10$bDn/sYGyGftalj96jLH5XebDapB3kUNWo1WymEvYZ7Szhnhf9f4ea	2026-01-28 18:47:37.482127+00	\N		\N		2026-01-28 18:47:37.482127+00			\N	2026-02-04 22:38:31.99806+00	{"provider": "email", "providers": ["email"]}	{"email": "jhordan@cevd.com", "perfil": "Advanced", "full_name": "Jhordan"}	\N	2026-01-28 18:47:37.482127+00	2026-02-04 22:38:32.018968+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e74c904e-6dcd-4536-af23-74401f842f22	authenticated	authenticated	ewerton@cevd.com	$2a$10$r8Chsk7PEA9.lEue8goH5u8sep0zAMCl5j.Wc4ZSoprkKAzvaKPBm	2026-01-28 18:47:37.482127+00	\N		\N		\N	118898c955041101bbb8b662240c6b29d6ff84dd5cad79b75cd31d87	ewerton.bezerra.silva@gmail.com	2026-02-04 03:48:36.464924+00	2026-04-09 21:18:10.304045+00	{"provider": "email", "providers": ["email"]}	{"email": "ewerton@cevd.com", "perfil": "Admin", "full_name": "Ewerton B Silva", "display_name": "Ewerton Silva"}	\N	2026-01-28 18:47:37.482127+00	2026-04-13 13:26:10.359802+00	\N	\N			\N	c6f4e08053897b53197c6bcbde2e0bbab69f256fa9962421c98ca992	0	\N		\N	f	\N	f
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
ee2a4422-b096-47b7-bfbb-541217503bf7	ee2a4422-b096-47b7-bfbb-541217503bf7	{"sub": "ee2a4422-b096-47b7-bfbb-541217503bf7", "email": "adjanio@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	f0f68db3-8cb6-4fcf-be47-aab765ec19e4
24d79386-6eea-4478-8f2c-5611192b7a0c	24d79386-6eea-4478-8f2c-5611192b7a0c	{"sub": "24d79386-6eea-4478-8f2c-5611192b7a0c", "email": "aleane@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	ee236c7c-ab80-47f5-b83e-eb37627fbcd9
18c7dd1b-8347-443d-b439-2bb8579b5386	18c7dd1b-8347-443d-b439-2bb8579b5386	{"sub": "18c7dd1b-8347-443d-b439-2bb8579b5386", "email": "cilene@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	fce33f67-c10c-4bab-9602-fd0807959b02
88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	{"sub": "88b364cf-5b9d-43ed-a01d-c7da6ce1e22e", "email": "dany@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	45251c86-29f1-415e-b10c-b0a6958545fb
a1d9f814-46e4-48d4-8262-b3fce5cb0fd6	a1d9f814-46e4-48d4-8262-b3fce5cb0fd6	{"sub": "a1d9f814-46e4-48d4-8262-b3fce5cb0fd6", "email": "eduardo@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	6f6a22d8-178e-42c6-aa7b-87f9afba8662
e74c904e-6dcd-4536-af23-74401f842f22	e74c904e-6dcd-4536-af23-74401f842f22	{"sub": "e74c904e-6dcd-4536-af23-74401f842f22", "email": "ewerton@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	37c8dcb0-3e80-462d-8776-f515aff026fe
b64a4caa-b645-414e-a213-d3076076922b	b64a4caa-b645-414e-a213-d3076076922b	{"sub": "b64a4caa-b645-414e-a213-d3076076922b", "email": "felipe@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	62aa48ca-59d9-40f4-bc01-e03fee827d35
96d801f5-58e6-444f-9416-d6817bb47042	96d801f5-58e6-444f-9416-d6817bb47042	{"sub": "96d801f5-58e6-444f-9416-d6817bb47042", "email": "gabriel@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	b7a5eeb8-03af-4643-b1fe-94ec50188163
ec5dc436-f243-49d2-a66b-c114b6811ea0	ec5dc436-f243-49d2-a66b-c114b6811ea0	{"sub": "ec5dc436-f243-49d2-a66b-c114b6811ea0", "email": "guilherme@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	76c77d2e-6b34-49d5-b0ef-3126ed96e5b0
6993a591-8905-49e7-a35e-3eda54081713	6993a591-8905-49e7-a35e-3eda54081713	{"sub": "6993a591-8905-49e7-a35e-3eda54081713", "email": "henrique@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	33048b92-f570-46f9-863b-fdb26606b969
dff6aff0-a4ac-4141-bda1-8e8ffa04cfff	dff6aff0-a4ac-4141-bda1-8e8ffa04cfff	{"sub": "dff6aff0-a4ac-4141-bda1-8e8ffa04cfff", "email": "isis@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	c60cc12c-4831-4405-9966-cc77fc03047d
414350c9-e858-4dee-85e4-a93c3a05bced	414350c9-e858-4dee-85e4-a93c3a05bced	{"sub": "414350c9-e858-4dee-85e4-a93c3a05bced", "email": "jessé@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	3b621484-7e9a-4c63-a167-2a4866f45c88
23d2d224-8f94-4e4f-ab13-7e8868e20611	23d2d224-8f94-4e4f-ab13-7e8868e20611	{"sub": "23d2d224-8f94-4e4f-ab13-7e8868e20611", "email": "jhordan@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	aa45129d-e10d-4b10-9bc9-9371fe8e90c5
7e79b82c-fc1f-4322-8200-9c371805abe3	7e79b82c-fc1f-4322-8200-9c371805abe3	{"sub": "7e79b82c-fc1f-4322-8200-9c371805abe3", "email": "kaká@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	b348a205-3a3e-43d1-b1a2-be1f628264bc
03a18d33-f884-43a5-a579-162578daac5a	03a18d33-f884-43a5-a579-162578daac5a	{"sub": "03a18d33-f884-43a5-a579-162578daac5a", "email": "lucas@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	91b2eb3d-0932-48b4-bc90-6ecdedf4d5e2
1563eb41-f8ad-4ff8-a141-778e4e73a288	1563eb41-f8ad-4ff8-a141-778e4e73a288	{"sub": "1563eb41-f8ad-4ff8-a141-778e4e73a288", "email": "marcos@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	a70ef054-6ffe-40bc-958c-16b94b9b402a
04696c14-57f5-4492-a09d-91a4bd2aea80	04696c14-57f5-4492-a09d-91a4bd2aea80	{"sub": "04696c14-57f5-4492-a09d-91a4bd2aea80", "email": "marilei@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	1f03c58c-db2a-448d-91b3-23fbd6906284
35be7e54-5d03-4e92-9304-abe4ca3885e8	35be7e54-5d03-4e92-9304-abe4ca3885e8	{"sub": "35be7e54-5d03-4e92-9304-abe4ca3885e8", "email": "mikeias@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	df32f9ac-0a1d-49b6-8828-2afdcc7929ee
51306dad-b8e0-46b4-aaa4-24510690a705	51306dad-b8e0-46b4-aaa4-24510690a705	{"sub": "51306dad-b8e0-46b4-aaa4-24510690a705", "email": "naira@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	90a8e481-5829-46ec-b653-33e63875728f
332c48aa-eb34-452a-971e-5f3dbafad987	332c48aa-eb34-452a-971e-5f3dbafad987	{"sub": "332c48aa-eb34-452a-971e-5f3dbafad987", "email": "nayane@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	9b611085-b29e-4a98-91dd-cd64cdfa2908
2ee9bbd2-f0e0-4e42-b7ca-a1eba002783b	2ee9bbd2-f0e0-4e42-b7ca-a1eba002783b	{"sub": "2ee9bbd2-f0e0-4e42-b7ca-a1eba002783b", "email": "rosy@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	0c91a847-60ff-426b-a5c3-16c9d9820b94
49eee164-7639-4d09-9a19-997955cef4d5	49eee164-7639-4d09-9a19-997955cef4d5	{"sub": "49eee164-7639-4d09-9a19-997955cef4d5", "email": "veronica@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	d8481d7c-f409-4c5e-9e7e-b1af95d53a95
4db36368-05b1-4fd4-ac13-c8a8c06ba5f9	4db36368-05b1-4fd4-ac13-c8a8c06ba5f9	{"sub": "4db36368-05b1-4fd4-ac13-c8a8c06ba5f9", "email": "wesley@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	47729bac-78ae-4414-8aac-20a16518afba
e49d2c9b-6744-497c-bb61-b58abcb6c7e5	e49d2c9b-6744-497c-bb61-b58abcb6c7e5	{"sub": "e49d2c9b-6744-497c-bb61-b58abcb6c7e5", "email": "yokennan@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	09bc77d1-e3a8-4101-9782-b74837388fc0
c7d4a12b-47a4-498d-baf0-1ce0a0212bb2	c7d4a12b-47a4-498d-baf0-1ce0a0212bb2	{"sub": "c7d4a12b-47a4-498d-baf0-1ce0a0212bb2", "email": "v.rodrigues@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	e5f4e3bd-1ff7-43f3-bb5d-c1e03fb62ed2
2577d100-73c8-4579-9de2-4e76818a027e	2577d100-73c8-4579-9de2-4e76818a027e	{"sub": "2577d100-73c8-4579-9de2-4e76818a027e", "email": "v.mesquita@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	75ef878b-c589-4d45-85a6-4ce08da7957d
4b543930-107b-4580-b00f-958769fa4400	4b543930-107b-4580-b00f-958769fa4400	{"sub": "4b543930-107b-4580-b00f-958769fa4400", "email": "anne.gabrielly@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	e52f2277-f967-425d-bcae-8cb96e4eede6
e7fae8f4-1411-459b-af01-0eefdaa7e57c	e7fae8f4-1411-459b-af01-0eefdaa7e57c	{"sub": "e7fae8f4-1411-459b-af01-0eefdaa7e57c", "email": "ana.clara@CEVD.com"}	email	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	2026-01-28 18:47:37.482127+00	81d6fb50-575d-4015-b20a-7ca2eda12d7d
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
0ca5d1b4-5a86-4d60-979f-534f52debbce	23d2d224-8f94-4e4f-ab13-7e8868e20611	2026-02-04 22:38:31.998752+00	2026-02-04 22:38:31.998752+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	170.83.174.126	\N	\N	\N	\N	\N
69f0d1f1-e870-4fd2-bafd-36cb8ec57884	e74c904e-6dcd-4536-af23-74401f842f22	2026-04-09 17:02:52.512243+00	2026-04-09 20:07:35.075766+00	\N	aal1	\N	2026-04-09 20:07:35.075651	Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36	187.255.176.5	\N	\N	\N	\N	\N
2167263c-0b71-4dad-bcbe-b8fe92ef3b89	e74c904e-6dcd-4536-af23-74401f842f22	2026-04-09 21:18:10.304144+00	2026-04-09 21:18:10.304144+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	187.255.176.5	\N	\N	\N	\N	\N
9eccd651-6a02-4a51-88fa-0f841694e3e7	e74c904e-6dcd-4536-af23-74401f842f22	2026-04-09 20:37:17.031732+00	2026-04-13 13:26:10.373805+00	\N	aal1	\N	2026-04-13 13:26:10.373681	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	187.255.176.5	\N	\N	\N	\N	\N
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
0ca5d1b4-5a86-4d60-979f-534f52debbce	2026-02-04 22:38:32.019659+00	2026-02-04 22:38:32.019659+00	password	59ee7d1b-bd2b-4635-a390-7a7992361d54
69f0d1f1-e870-4fd2-bafd-36cb8ec57884	2026-04-09 17:02:52.532364+00	2026-04-09 17:02:52.532364+00	password	9c2ec5ca-673f-4a37-b415-29092c9db705
9eccd651-6a02-4a51-88fa-0f841694e3e7	2026-04-09 20:37:17.100831+00	2026-04-09 20:37:17.100831+00	password	25d18b11-4564-40f6-ae83-cb3ed35e811c
2167263c-0b71-4dad-bcbe-b8fe92ef3b89	2026-04-09 21:18:10.332671+00	2026-04-09 21:18:10.332671+00	password	18ae82eb-cbaa-464f-bf5c-04a85ed11c7e
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
44e6ad68-1486-41d5-99f7-f0745c246e3a	e74c904e-6dcd-4536-af23-74401f842f22	email_change_token_current	c6f4e08053897b53197c6bcbde2e0bbab69f256fa9962421c98ca992	ewerton@cevd.com	2026-02-04 03:48:37.622559	2026-02-04 03:48:37.622559
c094932d-8b34-4551-a4de-c3922fbc3d93	e74c904e-6dcd-4536-af23-74401f842f22	email_change_token_new	118898c955041101bbb8b662240c6b29d6ff84dd5cad79b75cd31d87	ewerton.bezerra.silva@gmail.com	2026-02-04 03:48:37.634776	2026-02-04 03:48:37.634776
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
00000000-0000-0000-0000-000000000000	110	uf3l6mby44rd	e74c904e-6dcd-4536-af23-74401f842f22	t	2026-04-09 17:02:52.526616+00	2026-04-09 18:04:04.739883+00	\N	69f0d1f1-e870-4fd2-bafd-36cb8ec57884
00000000-0000-0000-0000-000000000000	111	pmhknnkk6lsd	e74c904e-6dcd-4536-af23-74401f842f22	t	2026-04-09 18:04:04.760244+00	2026-04-09 19:05:34.917918+00	uf3l6mby44rd	69f0d1f1-e870-4fd2-bafd-36cb8ec57884
00000000-0000-0000-0000-000000000000	112	ykagad2sgozm	e74c904e-6dcd-4536-af23-74401f842f22	t	2026-04-09 19:05:34.94443+00	2026-04-09 20:07:35.041392+00	pmhknnkk6lsd	69f0d1f1-e870-4fd2-bafd-36cb8ec57884
00000000-0000-0000-0000-000000000000	113	crv4vxrulhma	e74c904e-6dcd-4536-af23-74401f842f22	f	2026-04-09 20:07:35.054012+00	2026-04-09 20:07:35.054012+00	ykagad2sgozm	69f0d1f1-e870-4fd2-bafd-36cb8ec57884
00000000-0000-0000-0000-000000000000	115	v2nrvmteztc5	e74c904e-6dcd-4536-af23-74401f842f22	f	2026-04-09 21:18:10.32337+00	2026-04-09 21:18:10.32337+00	\N	2167263c-0b71-4dad-bcbe-b8fe92ef3b89
00000000-0000-0000-0000-000000000000	114	7xz5vrgmqjd4	e74c904e-6dcd-4536-af23-74401f842f22	t	2026-04-09 20:37:17.065281+00	2026-04-13 13:26:10.30676+00	\N	9eccd651-6a02-4a51-88fa-0f841694e3e7
00000000-0000-0000-0000-000000000000	116	uepmfsbleyfr	e74c904e-6dcd-4536-af23-74401f842f22	f	2026-04-13 13:26:10.340556+00	2026-04-13 13:26:10.340556+00	7xz5vrgmqjd4	9eccd651-6a02-4a51-88fa-0f841694e3e7
00000000-0000-0000-0000-000000000000	63	emtvgs734cxt	23d2d224-8f94-4e4f-ab13-7e8868e20611	f	2026-02-04 22:38:32.012262+00	2026-02-04 22:38:32.012262+00	\N	0ca5d1b4-5a86-4d60-979f-534f52debbce
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: membros; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."membros" ("id", "nome", "telefone", "ativo", "genero", "created_at", "foto", "perfil", "email", "data_nasc") FROM stdin;
03a18d33-f884-43a5-a579-162578daac5a	Lucas	68 9 9227-5290	t	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/lucas.png"	Advanced	lucas@cevd.com	\N
6b269cc2-3352-41b0-9286-52cd423f30e9	Convidado	\N	t	\N	2026-01-27 23:21:47.185069+00	\N	\N	\N	\N
2577d100-73c8-4579-9de2-4e76818a027e	V. Mesquita	68 9 9940-3079	t	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/v__mesquita.png"	User	v.mesquita@cevd.com	\N
24d79386-6eea-4478-8f2c-5611192b7a0c	Aleane	68 9 9240-4797	t	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/aleane.png"	User	aleane@cevd.com	\N
7e79b82c-fc1f-4322-8200-9c371805abe3	Kaká	68 9 9960-0383	f	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/kaka.png"	User	kaká@cevd.com	\N
b64a4caa-b645-414e-a213-d3076076922b	Felipe	68 9 9225-3562	t	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/felipe.png"	Advanced	felipe@cevd.com	\N
414350c9-e858-4dee-85e4-a93c3a05bced	Jessé	68 9 9608-2809	t	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/jesse.png"	Advanced	jessé@cevd.com	\N
96d801f5-58e6-444f-9416-d6817bb47042	Gabriel	68 9 9237-7440	t	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/gabriel.png"	User	gabriel@cevd.com	\N
ec5dc436-f243-49d2-a66b-c114b6811ea0	Guilherme	68 9 9905-7276	f	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/guilherme.png"	User	guilherme@cevd.com	\N
e74c904e-6dcd-4536-af23-74401f842f22	Ewerton	68 9 9971-0406	t	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/ewerton.png"	admin	ewerton@CEVD.com	1994-12-31
23d2d224-8f94-4e4f-ab13-7e8868e20611	Jhordan	68 9 9203-7424	t	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/jhordan.png"	Advanced	jhordan@cevd.com	\N
dff6aff0-a4ac-4141-bda1-8e8ffa04cfff	Isis	68 9 9246-3437	t	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/isis.png"	User	isis@cevd.com	\N
6993a591-8905-49e7-a35e-3eda54081713	Henrique	68 9 9925-1882	f	Homem	2026-01-27 23:21:47.185069+00	\N	User	henrique@cevd.com	\N
a1d9f814-46e4-48d4-8262-b3fce5cb0fd6	Eduardo	68 9 8111-3170	t	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/eduardo.png"	User	eduardo@cevd.com	\N
e7fae8f4-1411-459b-af01-0eefdaa7e57c	Ana Clara	68 9 9241-6481	t	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/ana_clara.png"	User	ana.clara@cevd.com	\N
c7d4a12b-47a4-498d-baf0-1ce0a0212bb2	V. Rodrigues	69 9 9905-7249	f	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/v__rodrigues.png"	User	v.rodrigues@cevd.com	\N
18c7dd1b-8347-443d-b439-2bb8579b5386	Cilene	68 9 9997-4077	f	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/cilene.png"	User	cilene@cevd.com	\N
88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	Dany	68 9 9909-7409	f	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/dany.png"	User	dany@cevd.com	\N
4db36368-05b1-4fd4-ac13-c8a8c06ba5f9	Wesley	68 9 8428-7354	f	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/wesley.png"	User	wesley@cevd.com	\N
e49d2c9b-6744-497c-bb61-b58abcb6c7e5	Yokennan	68 9 8426-2919	f	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/yokennan.png"	User	yokennan@cevd.com	\N
ee2a4422-b096-47b7-bfbb-541217503bf7	Adjanio	68 9 9945-3923	f	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/adjanio.png"	User	adjanio@cevd.com	\N
2ee9bbd2-f0e0-4e42-b7ca-a1eba002783b	Rosy	68 9 9220-4890	t	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/rosy.png"	User	rosy@cevd.com	\N
51306dad-b8e0-46b4-aaa4-24510690a705	Naira	68 9 9222-8296	t	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/naira.png"	User	naira@cevd.com	\N
4b543930-107b-4580-b00f-958769fa4400	Anne Gabrielly	68 9 9980-2988	t	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/anne_gabrielly.png"	User	anne.gabrielly@cevd.com	\N
1563eb41-f8ad-4ff8-a141-778e4e73a288	Marcos	68 9 9954-5997	t	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/marcos.png"	User	marcos@cevd.com	\N
04696c14-57f5-4492-a09d-91a4bd2aea80	Marilei	68 9 9928-6346	t	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/marilei.png"	User	marilei@cevd.com	\N
35be7e54-5d03-4e92-9304-abe4ca3885e8	Mikeias	68 9 9206-2605	t	Homem	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/mikeias.png"	Advanced	mikeias@cevd.com	\N
332c48aa-eb34-452a-971e-5f3dbafad987	Nayane	68 9 9240-4264	f	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/nayane.png"	User	nayane@cevd.com	\N
49eee164-7639-4d09-9a19-997955cef4d5	Veronica	68 9 9972-5019	f	Mulher	2026-01-27 23:21:47.185069+00	"https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/membros/veronica.png"	User	veronica@cevd.com	\N
\.


--
-- Data for Name: aviso_geral; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."aviso_geral" ("id", "created_at", "id_membro", "texto") FROM stdin;
1	2025-09-10	e7fae8f4-1411-459b-af01-0eefdaa7e57c	não tô conseguindo mais me comprometer com as coisas do louvor, nn consigo ir pra alguns ensaios… Por conta da rotina e por conta de outras responsabilidades minhas. Eu não acho certo e nn quero estar em um ministério só por estar, tenho que ter compromisso e ultimamente não tô conseguindo ter então, tô querendo sair do louvor.  Resolução: Se o problema for tempo, eu posso reduzir a quantidade de escala, Deixa só aos sábados e Reduzir a quantidade de sábados ficando 2 sábados no mes
2	2025-09-10	49eee164-7639-4d09-9a19-997955cef4d5	Vou da um tempo da escala porque estou muita atarefada e não estou conseguindo conciliar com o ministério, e não quero fazer de qualquer jeito.
3	2025-10-01	2577d100-73c8-4579-9de2-4e76818a027e	Amg, boa noite! Queria que a escala de domingo agora fosse a minha última até novembro por conta do Enem. Falta 1 mês a contar de amanhã. Eu tô doidinha, muito pilhada. Aí nas duas primeiras semanas de Novembro eu tô off. Depois disso, eu estou on.
4	2026-01-26	35be7e54-5d03-4e92-9304-abe4ca3885e8	Mano, tem como eu ficar um tempo fora das escalas
5	2026-01-10	a1d9f814-46e4-48d4-8262-b3fce5cb0fd6	Man, Welligton pediu para eu ficar fora das escala por um tempo.
\.


--
-- Data for Name: nome_cultos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."nome_cultos" ("id", "nome_culto", "created_at") FROM stdin;
239f88d1-cb30-4a42-b82b-9908e142a0c5	Campanha	2026-01-28 04:01:20.821707+00
97ae4e7a-12aa-42dc-9dfc-69a4731323d0	Celebração 	2026-01-28 04:01:20.821707+00
48ddd611-ffc3-433d-836d-f975cd152e2a	Conferência 	2026-01-28 04:01:20.821707+00
9f99b6eb-437e-4463-b097-b72fab783a3c	Consagração	2026-01-28 04:01:20.821707+00
ec28eb5e-0a61-4ef2-8aab-335f906a74d7	Culto da Virada	2026-01-28 04:01:20.821707+00
3d099ff6-25f0-4613-bcf0-e5e5d9836636	Culto de Adoraçao	2026-01-28 04:01:20.821707+00
596a9e77-d3d3-41f7-baf5-39fadd5628ce	Culto dos Idosos	2026-01-28 04:01:20.821707+00
b7f38aed-2221-4b63-936d-57a15a79a80d	Evangelístico	2026-01-28 04:01:20.821707+00
fb1ebb04-89a1-4b20-a7f4-659cf001199c	Família	2026-01-28 04:01:20.821707+00
94cb7ba5-1075-4b12-9ae5-6d64d523f24e	Festa das Células	2026-01-28 04:01:20.821707+00
8ce80247-4969-45f6-90c1-95c5ed066f78	Homens	2026-01-28 04:01:20.821707+00
a50f8e8e-31b5-46a5-999c-8d11aeb92619	Jovens	2026-01-28 04:01:20.821707+00
d7f5dfbf-1283-4a40-880c-9a487db5c747	Mulheres	2026-01-28 04:01:20.821707+00
90f99719-8611-41db-954e-4eb5b032dad9	Passos de Fé	2026-01-28 04:01:20.821707+00
cd019acb-d5bb-46b2-9215-1c0473ea55da	Reunião	2026-01-28 04:01:20.821707+00
cf9aa2b7-c6c5-4e42-bc76-50511e07ce2a	Santa Ceia 	2026-01-28 04:01:20.821707+00
3a26946b-1495-4ba7-a10d-b76904477fb2	Seminário 	2026-01-28 04:01:20.821707+00
7335f802-cff8-4cc5-8fca-db0d3970801b	Vigília 	2026-01-28 04:01:20.821707+00
9dd320de-547c-4304-bfd8-69ec2671f1a2	Convenção Estadual	2026-01-28 04:01:20.821707+00
\.


--
-- Data for Name: cultos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."cultos" ("id", "data_culto", "id_nome_cultos", "horario") FROM stdin;
806a29f9-baf4-4adf-8188-ef658827154e	2026-01-13	239f88d1-cb30-4a42-b82b-9908e142a0c5	19:00:00
ad7c8ae8-0bb8-4811-a3d3-23c828064db8	2026-01-17	239f88d1-cb30-4a42-b82b-9908e142a0c5	19:00:00
043b5b3a-e031-4587-ab41-6a5e8aa78719	2026-01-16	239f88d1-cb30-4a42-b82b-9908e142a0c5	19:00:00
0d387490-7a27-4ddd-abb3-247350aeab54	2026-01-15	239f88d1-cb30-4a42-b82b-9908e142a0c5	19:00:00
025db669-d43a-4973-9871-fbd6352799a3	2026-01-12	239f88d1-cb30-4a42-b82b-9908e142a0c5	19:00:00
5c034fbe-63ca-432d-a291-eb550d17e53f	2026-01-08	239f88d1-cb30-4a42-b82b-9908e142a0c5	19:00:00
2607af38-cd58-43be-9130-773e41292909	2026-01-10	239f88d1-cb30-4a42-b82b-9908e142a0c5	19:00:00
2287a63c-076c-41e5-9b32-ebc78336dc76	2026-01-14	239f88d1-cb30-4a42-b82b-9908e142a0c5	19:00:00
b6d91469-6fa2-440a-8657-782452e306fe	2026-01-09	239f88d1-cb30-4a42-b82b-9908e142a0c5	19:00:00
6fd8a4ca-c821-4b3d-b6e1-77b7c6c49474	2026-01-18	97ae4e7a-12aa-42dc-9dfc-69a4731323d0	19:00:00
b20259b5-1945-44db-b448-e377197e8c88	2026-01-25	97ae4e7a-12aa-42dc-9dfc-69a4731323d0	19:00:00
94c45a91-ce82-4f6d-b151-05a415b8bff9	2026-01-04	97ae4e7a-12aa-42dc-9dfc-69a4731323d0	19:00:00
fa909d59-8a8f-49ca-9932-6ffc7230c891	2026-01-11	97ae4e7a-12aa-42dc-9dfc-69a4731323d0	19:00:00
8451067e-2f20-4c8a-8fef-bb6e171d270b	2026-01-25	596a9e77-d3d3-41f7-baf5-39fadd5628ce	19:00:00
8167d054-4afa-4391-be87-8ad96db960cd	2026-01-04	596a9e77-d3d3-41f7-baf5-39fadd5628ce	19:00:00
355ad5af-0faf-4454-9c1a-a7b73ede3dab	2026-01-18	596a9e77-d3d3-41f7-baf5-39fadd5628ce	19:00:00
6ac8d46b-9b29-4356-a49c-2bf053303df2	2026-02-01	596a9e77-d3d3-41f7-baf5-39fadd5628ce	19:00:00
91c451fe-80e1-488f-a1e5-c47866b055fa	2026-01-11	596a9e77-d3d3-41f7-baf5-39fadd5628ce	19:00:00
9c65a06c-5eb0-4f48-a465-8f605127c651	2026-01-01	90f99719-8611-41db-954e-4eb5b032dad9	19:00:00
87d705de-579f-45a8-ae37-85c9805960a7	2026-02-01	cf9aa2b7-c6c5-4e42-bc76-50511e07ce2a	19:00:00
ac7a40cb-5831-43d1-a805-584d2610a669	2026-01-03	3a26946b-1495-4ba7-a10d-b76904477fb2	19:00:00
9338d5b8-e1ad-4d3c-b5c3-911fa653f1e9	2026-01-06	3a26946b-1495-4ba7-a10d-b76904477fb2	19:00:00
0dc81993-5781-4c77-99a9-648b19492fd4	2026-01-02	3a26946b-1495-4ba7-a10d-b76904477fb2	19:00:00
54ce825d-5313-436b-b8cd-576d0ea392ba	2026-03-31	239f88d1-cb30-4a42-b82b-9908e142a0c5	19:00:00
\.


--
-- Data for Name: avisos_cultos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."avisos_cultos" ("id_lembrete", "id_membros", "id_cultos", "info", "created_at") FROM stdin;
\.


--
-- Data for Name: funcao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."funcao" ("id", "created_at", "nome_funcao") FROM stdin;
1	2026-01-28 21:11:39.750489+00	Ministro
3	2026-01-28 21:11:39.750489+00	Violão
4	2026-01-28 21:11:39.750489+00	Teclado
5	2026-01-28 21:11:39.750489+00	Guitarra
6	2026-01-28 21:11:39.750489+00	Baixo
7	2026-01-28 21:11:39.750489+00	Bateria
8	2026-01-28 21:11:58.557046+00	Sax
2	2026-01-28 21:11:39.750489+00	Vocal
\.


--
-- Data for Name: escalas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."escalas" ("id", "data_ensaio", "horario_ensaio", "created_at", "id_culto", "id_membros", "id_funcao") FROM stdin;
2b970120-3919-4cf4-8649-fc86bba00a6b	\N	\N	2026-01-27 23:22:40.319431+00	9338d5b8-e1ad-4d3c-b5c3-911fa653f1e9	414350c9-e858-4dee-85e4-a93c3a05bced	6
30c18ce4-a51d-4213-b994-65c3787b7652	\N	\N	2026-01-27 23:22:40.319431+00	9338d5b8-e1ad-4d3c-b5c3-911fa653f1e9	03a18d33-f884-43a5-a579-162578daac5a	7
85d28beb-8887-47c8-a905-77d01fadbe3f	\N	\N	2026-01-27 23:22:40.319431+00	5c034fbe-63ca-432d-a291-eb550d17e53f	414350c9-e858-4dee-85e4-a93c3a05bced	1
fae9e5c7-e0ba-445b-b381-33fda22cb5af	\N	\N	2026-01-27 23:22:40.319431+00	5c034fbe-63ca-432d-a291-eb550d17e53f	04696c14-57f5-4492-a09d-91a4bd2aea80	1
47a2d2f1-6c96-4ac9-bea1-2f07008254dd	\N	\N	2026-01-27 23:22:40.319431+00	5c034fbe-63ca-432d-a291-eb550d17e53f	51306dad-b8e0-46b4-aaa4-24510690a705	2
30dd8d2f-3520-4275-9dd8-be3ae8b0942d	\N	\N	2026-01-27 23:22:40.319431+00	5c034fbe-63ca-432d-a291-eb550d17e53f	414350c9-e858-4dee-85e4-a93c3a05bced	3
c70b8972-d52c-4596-8e71-2c0313e70701	\N	\N	2026-01-27 23:22:40.319431+00	5c034fbe-63ca-432d-a291-eb550d17e53f	35be7e54-5d03-4e92-9304-abe4ca3885e8	6
44fc9f42-f674-4725-adb5-4fcaa9e227cd	\N	\N	2026-01-27 23:22:40.319431+00	5c034fbe-63ca-432d-a291-eb550d17e53f	03a18d33-f884-43a5-a579-162578daac5a	7
7fe9eb76-567d-401d-a469-840b33fccc5b	\N	\N	2026-01-27 23:22:40.319431+00	b6d91469-6fa2-440a-8657-782452e306fe	03a18d33-f884-43a5-a579-162578daac5a	1
f092b404-8c4c-45fa-98e9-9e2525ff82a3	\N	\N	2026-01-27 23:22:40.319431+00	b6d91469-6fa2-440a-8657-782452e306fe	24d79386-6eea-4478-8f2c-5611192b7a0c	1
9da630e3-bd78-426a-8b64-294c11b906d5	\N	\N	2026-01-27 23:22:40.319431+00	806a29f9-baf4-4adf-8188-ef658827154e	414350c9-e858-4dee-85e4-a93c3a05bced	3
561a8010-4d08-4b66-9db1-5af9173729f2	\N	\N	2026-01-27 23:22:40.319431+00	806a29f9-baf4-4adf-8188-ef658827154e	35be7e54-5d03-4e92-9304-abe4ca3885e8	6
37337ec3-fc98-4173-a6c8-cf4fb5deeef2	\N	\N	2026-01-27 23:22:40.319431+00	806a29f9-baf4-4adf-8188-ef658827154e	b64a4caa-b645-414e-a213-d3076076922b	7
222e6631-abe8-46ef-b097-df931176593c	\N	\N	2026-01-27 23:22:40.319431+00	2287a63c-076c-41e5-9b32-ebc78336dc76	6b269cc2-3352-41b0-9286-52cd423f30e9	1
81eff800-0e30-49c0-afb2-f36f5e4b48a1	\N	\N	2026-01-27 23:22:40.319431+00	2287a63c-076c-41e5-9b32-ebc78336dc76	6b269cc2-3352-41b0-9286-52cd423f30e9	2
0ff3e30d-4501-4be8-9dd9-0bfe50865815	\N	\N	2026-01-27 23:22:40.319431+00	2287a63c-076c-41e5-9b32-ebc78336dc76	4b543930-107b-4580-b00f-958769fa4400	2
71f2e210-4cd5-4e69-9996-24d51c6784b9	\N	\N	2026-01-27 23:22:40.319431+00	2287a63c-076c-41e5-9b32-ebc78336dc76	414350c9-e858-4dee-85e4-a93c3a05bced	6
cf48a09f-d3d0-4ff7-8943-b0058d6cca0d	\N	\N	2026-01-27 23:22:40.319431+00	2287a63c-076c-41e5-9b32-ebc78336dc76	6b269cc2-3352-41b0-9286-52cd423f30e9	7
384954f1-dcd6-4ad1-b234-929cb1f22733	\N	\N	2026-01-27 23:22:40.319431+00	0d387490-7a27-4ddd-abb3-247350aeab54	414350c9-e858-4dee-85e4-a93c3a05bced	1
6cd80154-6b15-4fb5-94c4-8ff49548ec6b	\N	\N	2026-01-27 23:22:40.319431+00	0d387490-7a27-4ddd-abb3-247350aeab54	04696c14-57f5-4492-a09d-91a4bd2aea80	1
05e782aa-d05d-48a6-ae8b-fd98a4abd543	\N	\N	2026-01-27 23:22:40.319431+00	0d387490-7a27-4ddd-abb3-247350aeab54	24d79386-6eea-4478-8f2c-5611192b7a0c	2
d629eb72-5319-4b6f-b07d-95c8bda2fc67	\N	\N	2026-01-27 23:22:40.319431+00	0d387490-7a27-4ddd-abb3-247350aeab54	414350c9-e858-4dee-85e4-a93c3a05bced	3
b32aaf37-c2bf-4f7d-aaf1-a6377c73d026	\N	\N	2026-01-27 23:22:40.319431+00	0d387490-7a27-4ddd-abb3-247350aeab54	35be7e54-5d03-4e92-9304-abe4ca3885e8	6
e6a09706-d8fb-46c0-af0a-534d9e9632cf	\N	\N	2026-01-27 23:22:40.319431+00	0d387490-7a27-4ddd-abb3-247350aeab54	b64a4caa-b645-414e-a213-d3076076922b	7
78c206d2-137e-446f-847e-2cf70478c1d7	\N	\N	2026-01-27 23:22:40.319431+00	043b5b3a-e031-4587-ab41-6a5e8aa78719	51306dad-b8e0-46b4-aaa4-24510690a705	2
37004598-4687-43c1-8d56-f490e6e44a92	\N	\N	2026-01-27 23:22:40.319431+00	043b5b3a-e031-4587-ab41-6a5e8aa78719	35be7e54-5d03-4e92-9304-abe4ca3885e8	6
89fc3841-9e65-4a3a-bb20-dabb82687995	\N	\N	2026-01-27 23:22:40.319431+00	043b5b3a-e031-4587-ab41-6a5e8aa78719	b64a4caa-b645-414e-a213-d3076076922b	7
5b54fdfb-3ba1-4c5f-afa2-db996dcb51b0	\N	\N	2026-01-27 23:22:40.319431+00	ad7c8ae8-0bb8-4811-a3d3-23c828064db8	2577d100-73c8-4579-9de2-4e76818a027e	2
55e22e92-853e-4e41-aec1-c4e657d07f7c	\N	\N	2026-01-27 23:22:40.319431+00	ad7c8ae8-0bb8-4811-a3d3-23c828064db8	414350c9-e858-4dee-85e4-a93c3a05bced	6
2229d414-8251-47ee-ac3b-6165bc4ce359	\N	\N	2026-01-27 23:22:40.319431+00	ad7c8ae8-0bb8-4811-a3d3-23c828064db8	03a18d33-f884-43a5-a579-162578daac5a	7
4959241d-691b-49ee-a604-4ab178b5fb1e	\N	\N	2026-01-27 23:22:40.319431+00	b6d91469-6fa2-440a-8657-782452e306fe	03a18d33-f884-43a5-a579-162578daac5a	3
0c9aa480-2493-499a-b247-20bf7efc56d3	\N	\N	2026-01-27 23:22:40.319431+00	b6d91469-6fa2-440a-8657-782452e306fe	414350c9-e858-4dee-85e4-a93c3a05bced	6
6e66d538-1a5c-492a-ad7d-0b35b063e626	\N	\N	2026-01-27 23:22:40.319431+00	b6d91469-6fa2-440a-8657-782452e306fe	b64a4caa-b645-414e-a213-d3076076922b	7
c5dc0e00-dac0-4c1f-8303-ff52e8363618	\N	\N	2026-01-27 23:22:40.319431+00	2607af38-cd58-43be-9130-773e41292909	03a18d33-f884-43a5-a579-162578daac5a	1
a45d56d8-8e4c-4503-a7a7-fc4ee3743d4b	\N	\N	2026-01-27 23:22:40.319431+00	2607af38-cd58-43be-9130-773e41292909	dff6aff0-a4ac-4141-bda1-8e8ffa04cfff	2
9f44434c-fb75-4fc8-8c0d-7e8874430065	\N	\N	2026-01-27 23:22:40.319431+00	2607af38-cd58-43be-9130-773e41292909	03a18d33-f884-43a5-a579-162578daac5a	3
c0ed955f-5b67-4584-a3e7-fb5be522bec3	\N	\N	2026-01-27 23:22:40.319431+00	2607af38-cd58-43be-9130-773e41292909	35be7e54-5d03-4e92-9304-abe4ca3885e8	6
7138a490-808a-4c89-acd3-7c0bd58f5a2f	\N	\N	2026-01-27 23:22:40.319431+00	2607af38-cd58-43be-9130-773e41292909	b64a4caa-b645-414e-a213-d3076076922b	7
167a3753-2af4-4924-a832-a40b0ef73869	\N	\N	2026-01-27 23:22:40.319431+00	91c451fe-80e1-488f-a1e5-c47866b055fa	35be7e54-5d03-4e92-9304-abe4ca3885e8	1
2fd24000-17ee-4ebb-8ae6-15048f27ca35	\N	\N	2026-01-27 23:22:40.319431+00	91c451fe-80e1-488f-a1e5-c47866b055fa	35be7e54-5d03-4e92-9304-abe4ca3885e8	3
46b94821-ea9b-4170-a9a7-d362694ed077	\N	\N	2026-01-27 23:22:40.319431+00	fa909d59-8a8f-49ca-9932-6ffc7230c891	414350c9-e858-4dee-85e4-a93c3a05bced	1
7e745860-b133-4e08-8749-50e73d1e534b	\N	\N	2026-01-27 23:22:40.319431+00	fa909d59-8a8f-49ca-9932-6ffc7230c891	24d79386-6eea-4478-8f2c-5611192b7a0c	2
396e1143-319c-4470-9c4d-00a19b946fe3	\N	\N	2026-01-27 23:22:40.319431+00	fa909d59-8a8f-49ca-9932-6ffc7230c891	414350c9-e858-4dee-85e4-a93c3a05bced	3
7c0a915e-7deb-4ccd-a248-ffd4becf965e	\N	\N	2026-01-27 23:22:40.319431+00	fa909d59-8a8f-49ca-9932-6ffc7230c891	23d2d224-8f94-4e4f-ab13-7e8868e20611	6
23fffa5c-10c5-46c8-a2be-e191f0946461	\N	\N	2026-01-27 23:22:40.319431+00	fa909d59-8a8f-49ca-9932-6ffc7230c891	6b269cc2-3352-41b0-9286-52cd423f30e9	7
886b920e-4d61-4326-ba9e-0dc5dde18193	\N	\N	2026-01-27 23:22:40.319431+00	025db669-d43a-4973-9871-fbd6352799a3	51306dad-b8e0-46b4-aaa4-24510690a705	2
b176e3cb-d3de-4415-a134-8a5ddcb0996d	\N	\N	2026-01-27 23:22:40.319431+00	025db669-d43a-4973-9871-fbd6352799a3	35be7e54-5d03-4e92-9304-abe4ca3885e8	6
ec40a289-a8ff-4b7f-98a9-4df02987f8e1	\N	\N	2026-01-27 23:22:40.319431+00	025db669-d43a-4973-9871-fbd6352799a3	b64a4caa-b645-414e-a213-d3076076922b	7
96d46715-8c88-4936-9105-a75a32632faa	\N	\N	2026-01-27 23:22:40.319431+00	806a29f9-baf4-4adf-8188-ef658827154e	414350c9-e858-4dee-85e4-a93c3a05bced	1
b1750544-a03a-4b08-9861-67038ecbdf1c	\N	\N	2026-01-27 23:22:40.319431+00	806a29f9-baf4-4adf-8188-ef658827154e	24d79386-6eea-4478-8f2c-5611192b7a0c	1
e3d5cee1-2217-4580-bc66-7f877449df11	\N	\N	2026-01-27 23:22:40.319431+00	9c65a06c-5eb0-4f48-a465-8f605127c651	23d2d224-8f94-4e4f-ab13-7e8868e20611	6
631b22a1-9841-40b0-a74e-7aa4801235c6	\N	\N	2026-01-27 23:22:40.319431+00	9c65a06c-5eb0-4f48-a465-8f605127c651	03a18d33-f884-43a5-a579-162578daac5a	7
2ea4d5bc-be2a-4358-8856-7c0008592e90	\N	\N	2026-01-27 23:22:40.319431+00	0dc81993-5781-4c77-99a9-648b19492fd4	03a18d33-f884-43a5-a579-162578daac5a	1
8269fdd0-f0cb-4c10-89b9-9969fc7ac0cc	\N	\N	2026-01-27 23:22:40.319431+00	0dc81993-5781-4c77-99a9-648b19492fd4	03a18d33-f884-43a5-a579-162578daac5a	3
fa877a09-77a1-44e3-aa60-f34be7c92216	\N	\N	2026-01-27 23:22:40.319431+00	ac7a40cb-5831-43d1-a805-584d2610a669	23d2d224-8f94-4e4f-ab13-7e8868e20611	1
8429eb88-42fa-4b7b-ba2e-7d3d545e2a4c	\N	\N	2026-01-27 23:22:40.319431+00	ac7a40cb-5831-43d1-a805-584d2610a669	23d2d224-8f94-4e4f-ab13-7e8868e20611	3
6037350d-e172-4b15-8c71-41820d4acd1b	\N	\N	2026-01-27 23:22:40.319431+00	ac7a40cb-5831-43d1-a805-584d2610a669	35be7e54-5d03-4e92-9304-abe4ca3885e8	6
036d54cb-d92b-4844-be4a-d72632ca01dc	\N	\N	2026-01-27 23:22:40.319431+00	8167d054-4afa-4391-be87-8ad96db960cd	23d2d224-8f94-4e4f-ab13-7e8868e20611	1
3e35725d-7c6d-4f38-9b94-309443f30f23	\N	\N	2026-01-27 23:22:40.319431+00	8167d054-4afa-4391-be87-8ad96db960cd	23d2d224-8f94-4e4f-ab13-7e8868e20611	3
533c008c-82ee-443b-87ba-e1743460c846	\N	\N	2026-01-27 23:22:40.319431+00	94c45a91-ce82-4f6d-b151-05a415b8bff9	2577d100-73c8-4579-9de2-4e76818a027e	2
dbf59407-8390-4d5e-a258-599e27051064	\N	\N	2026-01-27 23:22:40.319431+00	94c45a91-ce82-4f6d-b151-05a415b8bff9	2ee9bbd2-f0e0-4e42-b7ca-a1eba002783b	2
13ec4b5f-06f3-4b9e-9c2e-3547dc53b00f	\N	\N	2026-01-27 23:22:40.319431+00	94c45a91-ce82-4f6d-b151-05a415b8bff9	35be7e54-5d03-4e92-9304-abe4ca3885e8	6
45a659e9-c04d-4057-84a9-ebc964c7b036	\N	\N	2026-01-27 23:22:40.319431+00	94c45a91-ce82-4f6d-b151-05a415b8bff9	03a18d33-f884-43a5-a579-162578daac5a	7
77dd645a-3552-48e2-b01a-78c2aefb7124	\N	\N	2026-01-27 23:22:40.319431+00	355ad5af-0faf-4454-9c1a-a7b73ede3dab	04696c14-57f5-4492-a09d-91a4bd2aea80	1
4f5f5a1a-f944-46e5-9232-ae066f389e0c	\N	\N	2026-01-27 23:22:40.319431+00	9c65a06c-5eb0-4f48-a465-8f605127c651	2577d100-73c8-4579-9de2-4e76818a027e	2
7342e288-ae6b-4afc-b541-9c09ff988d15	\N	\N	2026-01-27 23:22:40.319431+00	355ad5af-0faf-4454-9c1a-a7b73ede3dab	1563eb41-f8ad-4ff8-a141-778e4e73a288	3
b78442d9-53f3-4670-9210-f10bd172cbfb	\N	\N	2026-01-27 23:22:40.319431+00	6fd8a4ca-c821-4b3d-b6e1-77b7c6c49474	2ee9bbd2-f0e0-4e42-b7ca-a1eba002783b	2
21f9ff03-63a8-4435-bb18-801e190517e9	\N	\N	2026-01-27 23:22:40.319431+00	6fd8a4ca-c821-4b3d-b6e1-77b7c6c49474	2577d100-73c8-4579-9de2-4e76818a027e	2
8c5dc54f-f609-4fe6-a127-57556c08c6d1	\N	\N	2026-01-27 23:22:40.319431+00	6fd8a4ca-c821-4b3d-b6e1-77b7c6c49474	23d2d224-8f94-4e4f-ab13-7e8868e20611	6
fea58f4f-7480-4f78-90ff-0615d97c241d	\N	\N	2026-01-27 23:22:40.319431+00	6fd8a4ca-c821-4b3d-b6e1-77b7c6c49474	03a18d33-f884-43a5-a579-162578daac5a	7
77841b8c-89dd-4093-8ab4-358c995ab592	\N	\N	2026-01-27 23:22:40.319431+00	8451067e-2f20-4c8a-8fef-bb6e171d270b	23d2d224-8f94-4e4f-ab13-7e8868e20611	1
46a72e4c-05bd-4e60-97b4-6dd52dc77f0d	\N	\N	2026-01-27 23:22:40.319431+00	8451067e-2f20-4c8a-8fef-bb6e171d270b	23d2d224-8f94-4e4f-ab13-7e8868e20611	3
4f89a441-4d1f-44a1-b7f4-bb3a4cf5acc5	\N	\N	2026-01-27 23:22:40.319431+00	b20259b5-1945-44db-b448-e377197e8c88	04696c14-57f5-4492-a09d-91a4bd2aea80	1
f6606db1-4b3a-4d9e-9a88-3bb201844784	\N	\N	2026-01-27 23:22:40.319431+00	b20259b5-1945-44db-b448-e377197e8c88	414350c9-e858-4dee-85e4-a93c3a05bced	1
b1ba370c-796c-4437-b6ab-cefc2b4de04d	\N	\N	2026-01-27 23:22:40.319431+00	b20259b5-1945-44db-b448-e377197e8c88	24d79386-6eea-4478-8f2c-5611192b7a0c	2
37e4a92d-def3-43a0-9155-add9d38edee2	\N	\N	2026-01-27 23:22:40.319431+00	b20259b5-1945-44db-b448-e377197e8c88	414350c9-e858-4dee-85e4-a93c3a05bced	3
7575030e-b748-4bc1-ac7e-60b944acb2c8	\N	\N	2026-01-27 23:22:40.319431+00	b20259b5-1945-44db-b448-e377197e8c88	35be7e54-5d03-4e92-9304-abe4ca3885e8	6
23396411-03e2-44c2-bff2-a5eb5fd416e8	\N	\N	2026-01-27 23:22:40.319431+00	b20259b5-1945-44db-b448-e377197e8c88	03a18d33-f884-43a5-a579-162578daac5a	7
f5126229-440b-4da8-95e5-82f10df9f624	\N	\N	2026-01-27 23:22:40.319431+00	6ac8d46b-9b29-4356-a49c-2bf053303df2	414350c9-e858-4dee-85e4-a93c3a05bced	1
b38d354e-794f-4342-8016-7492727c09d9	\N	\N	2026-01-27 23:22:40.319431+00	6ac8d46b-9b29-4356-a49c-2bf053303df2	414350c9-e858-4dee-85e4-a93c3a05bced	3
6c640a69-0d28-4956-a53d-99429336343b	\N	\N	2026-01-27 23:22:40.319431+00	87d705de-579f-45a8-ae37-85c9805960a7	2ee9bbd2-f0e0-4e42-b7ca-a1eba002783b	2
35db3665-47b5-4132-9da3-ae8d39f9e7c1	\N	\N	2026-01-27 23:22:40.319431+00	87d705de-579f-45a8-ae37-85c9805960a7	2577d100-73c8-4579-9de2-4e76818a027e	2
b80f5ce0-75f1-4043-9583-21ed8c3fa66f	\N	\N	2026-01-27 23:22:40.319431+00	87d705de-579f-45a8-ae37-85c9805960a7	23d2d224-8f94-4e4f-ab13-7e8868e20611	6
45dd832e-965c-481b-a858-01225c7dc84d	\N	\N	2026-01-27 23:22:40.319431+00	87d705de-579f-45a8-ae37-85c9805960a7	03a18d33-f884-43a5-a579-162578daac5a	7
bbe73492-f04a-4ef6-8916-006d5e3d8c72	\N	\N	2026-01-27 23:22:40.319431+00	9338d5b8-e1ad-4d3c-b5c3-911fa653f1e9	e74c904e-6dcd-4536-af23-74401f842f22	3
b9506bce-e2b0-4a38-a8b1-e47ec829e3b7	\N	\N	2026-01-27 23:22:40.319431+00	2287a63c-076c-41e5-9b32-ebc78336dc76	e74c904e-6dcd-4536-af23-74401f842f22	1
29e96469-0ee5-4a63-9871-f398cb7288e6	\N	\N	2026-01-27 23:22:40.319431+00	2287a63c-076c-41e5-9b32-ebc78336dc76	e74c904e-6dcd-4536-af23-74401f842f22	3
26809729-bf9f-4c6c-89b1-e314ed586840	\N	\N	2026-01-27 23:22:40.319431+00	043b5b3a-e031-4587-ab41-6a5e8aa78719	e74c904e-6dcd-4536-af23-74401f842f22	1
3ecf0cbf-7a4c-4189-a174-3c843af6a651	\N	\N	2026-01-27 23:22:40.319431+00	043b5b3a-e031-4587-ab41-6a5e8aa78719	e74c904e-6dcd-4536-af23-74401f842f22	3
8f8a6fb1-3fda-4f97-9aa1-e5abc6dbd8b6	\N	\N	2026-01-27 23:22:40.319431+00	ad7c8ae8-0bb8-4811-a3d3-23c828064db8	e74c904e-6dcd-4536-af23-74401f842f22	1
fc3578c4-a256-41d4-8265-eaeb2fc25dfa	\N	\N	2026-01-27 23:22:40.319431+00	ad7c8ae8-0bb8-4811-a3d3-23c828064db8	e74c904e-6dcd-4536-af23-74401f842f22	3
b2e0edb3-163e-458e-a237-43c3b17fafa2	\N	\N	2026-01-27 23:22:40.319431+00	9c65a06c-5eb0-4f48-a465-8f605127c651	e74c904e-6dcd-4536-af23-74401f842f22	1
125d2ee8-d0a1-42a2-b6eb-9d33fde89372	\N	\N	2026-01-27 23:22:40.319431+00	fa909d59-8a8f-49ca-9932-6ffc7230c891	e74c904e-6dcd-4536-af23-74401f842f22	5
b026c587-4d3d-4ea8-932d-84efa2b825ca	\N	\N	2026-01-27 23:22:40.319431+00	025db669-d43a-4973-9871-fbd6352799a3	e74c904e-6dcd-4536-af23-74401f842f22	1
4f8fd844-75c2-4e9d-bfe0-da4e24f06de6	\N	\N	2026-01-27 23:22:40.319431+00	025db669-d43a-4973-9871-fbd6352799a3	e74c904e-6dcd-4536-af23-74401f842f22	3
7741c764-2050-465e-b6f2-43b9d4409506	\N	\N	2026-01-27 23:22:40.319431+00	9c65a06c-5eb0-4f48-a465-8f605127c651	e74c904e-6dcd-4536-af23-74401f842f22	3
1013e79e-b2c4-4210-ac7e-80a066c4ff60	\N	\N	2026-01-27 23:22:40.319431+00	94c45a91-ce82-4f6d-b151-05a415b8bff9	e74c904e-6dcd-4536-af23-74401f842f22	1
e8916271-a996-42e0-981e-bedc8dc902c7	\N	\N	2026-01-27 23:22:40.319431+00	94c45a91-ce82-4f6d-b151-05a415b8bff9	e74c904e-6dcd-4536-af23-74401f842f22	3
3ec00c6e-ec5f-49ea-9353-386ef06c0773	\N	\N	2026-01-27 23:22:40.319431+00	9338d5b8-e1ad-4d3c-b5c3-911fa653f1e9	e74c904e-6dcd-4536-af23-74401f842f22	1
7e8cc448-5c05-4daa-8ab1-2bf721a37c7b	\N	\N	2026-01-27 23:22:40.319431+00	6fd8a4ca-c821-4b3d-b6e1-77b7c6c49474	e74c904e-6dcd-4536-af23-74401f842f22	1
4c421151-de8f-411a-a079-269aefcce53b	\N	\N	2026-01-27 23:22:40.319431+00	6fd8a4ca-c821-4b3d-b6e1-77b7c6c49474	e74c904e-6dcd-4536-af23-74401f842f22	3
b22d0d1c-39dc-41fe-9b9b-dfbd53fecfe6	\N	\N	2026-01-27 23:22:40.319431+00	87d705de-579f-45a8-ae37-85c9805960a7	e74c904e-6dcd-4536-af23-74401f842f22	1
b1d02671-ee64-4933-a0f6-ffae403c5ca8	\N	\N	2026-01-27 23:22:40.319431+00	87d705de-579f-45a8-ae37-85c9805960a7	e74c904e-6dcd-4536-af23-74401f842f22	3
d8195289-596c-46b9-9d96-3b0deda52595	\N	\N	2026-02-01 17:14:27.27864+00	9c65a06c-5eb0-4f48-a465-8f605127c651	2ee9bbd2-f0e0-4e42-b7ca-a1eba002783b	2
f218ffe4-283f-499b-952f-d05a282358e9	\N	\N	2026-03-07 06:24:57.978063+00	54ce825d-5313-436b-b8cd-576d0ea392ba	e74c904e-6dcd-4536-af23-74401f842f22	1
60f2865e-38ae-455c-909e-187686595605	\N	\N	2026-03-07 06:25:12.884785+00	54ce825d-5313-436b-b8cd-576d0ea392ba	e74c904e-6dcd-4536-af23-74401f842f22	3
\.


--
-- Data for Name: eventos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."eventos" ("id_evento", "data_evento", "tema", "created_at", "horario_evento") FROM stdin;
dd9b7478-ec46-4c43-ae56-e078033cb2ab	2026-02-02	Reunião	2026-02-04 03:28:15.739989+00	19:00:00
\.


--
-- Data for Name: temas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."temas" ("id", "nome_tema", "created_at") FROM stdin;
a42f4b94-236e-43d7-abea-e13b2578984e	Geral	2026-01-27 23:21:47.185069+00
7f4ffc68-3a3c-4a37-8e20-b75643076331	Passos de Fé	2026-01-27 23:21:47.185069+00
46f56494-3dd8-4722-ac40-ee5f2983e1b8	Evangelistico	2026-01-27 23:21:47.185069+00
e093616a-2319-4315-b391-d42da32dfbd5	Família	2026-01-27 23:21:47.185069+00
1578d778-ef09-487f-9e05-3f893a6a98dd	Comunhão	2026-01-27 23:21:47.185069+00
5b16c5a0-3b1c-4433-bbea-000e3e8849f5	Santa Ceia	2026-01-27 23:21:47.185069+00
ece5eaca-f728-43ad-a2dc-1937c4b48b4e	Cristocêntrica	2026-01-27 23:21:47.185069+00
4a909e09-0ac4-4526-868d-2482658955f5	Rendição	2026-01-27 23:21:47.185069+00
\.


--
-- Data for Name: musicas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."musicas" ("id", "estilo", "musica", "cantor", "created_at", "id_temas") FROM stdin;
78e3cc0f-0390-4a5a-af17-b001449d9200	Adoração	Restitui	Min. Apascentar	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
c6246211-aa24-441c-910a-aaed43a899fb	Adoração	Pra Te Adorar	Min. Marcados Pelo Sangue	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
23605d9c-10e2-4ee2-913a-d51ecdffe3f8	Adoração	Como Eu Te Amo	Fernandinho	2026-01-28 02:44:17.366572+00	a42f4b94-236e-43d7-abea-e13b2578984e
941aa0f3-e97b-4e65-9b56-3d319776ceeb	Adoração	Batiza-Me	Fernandinho	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
2c9dd047-b406-40af-92dd-85af95067d12	Adoração	Sem Ti Não Irei	Pr. Jason Lee Jones	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
8ac8bd32-9878-4515-bac2-e080e73fa418	Adoração	Nada Mais	David Quinlan	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
9ca7a982-17b4-4b74-abd0-93a60fccdb2d	Adoração	Poderoso Deus	Antonio Cirilo	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
f0d569b2-ea11-4001-8862-69358e05769e	Celebração	Diante De Ti	Quatro Por Um	2026-01-28 02:51:24.402462+00	a42f4b94-236e-43d7-abea-e13b2578984e
12ef7061-5e29-4d5e-ab41-37f046956401	Adoração	Tua Presença É Real	Antonio Cirilo	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
664686c8-838c-4f02-b594-479c48696be9	Adoração	Ao Único	Aline Barros	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
27de5a51-a0b6-4a38-972d-2a8670312607	Adoração	A Ele A Glória	Gabriela Rocha	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
d70d3c73-2f99-4e95-a3e3-475f32de5caf	Adoração	Aquieta Minh'alma	Min. Zoe	2026-01-28 02:51:43.778622+00	46f56494-3dd8-4722-ac40-ee5f2983e1b8
f010bf9b-9e6f-46bb-9c8f-93812984164d	Adoração	Até Que O Senhor Venha	Min. Zoe	2026-01-28 02:52:48.603008+00	a42f4b94-236e-43d7-abea-e13b2578984e
98ff7494-2bc9-48e6-8b49-5bdfddd6477e	Adoração	Em Espírito Em Verdade	Min. Koinonya De Louvor	2026-01-28 02:52:48.603008+00	4a909e09-0ac4-4526-868d-2482658955f5
56d23603-72bc-4946-b327-73ef7021478a	Adoração	Nada Temerei	Min. Atitude	2026-01-28 02:53:09.029896+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
fb8c1186-791a-43c6-9802-489cd0cf5da3	Adoração	Quanto Mais Eu Te Buscar	Min. Cristo Vivo	2026-01-28 02:53:30.903204+00	4a909e09-0ac4-4526-868d-2482658955f5
70e5e1cc-2aba-49cd-89ac-aa76d6e9e6cc	Adoração	Teu Jardim	Ouvir E Crer	2026-01-28 02:50:13.505435+00	a42f4b94-236e-43d7-abea-e13b2578984e
bf6ae4bc-4d12-46b1-b5a2-8130ad6f1f99	Adoração	Tu És O Dono Do Meu Coração	Ouvir E Crer	2026-01-28 02:50:13.505435+00	a42f4b94-236e-43d7-abea-e13b2578984e
70ddc76c-178c-4a98-a8ee-a12923042db7	Adoração	Eu Me Encontrei	Ouvir E Crer	2026-01-28 02:50:13.505435+00	a42f4b94-236e-43d7-abea-e13b2578984e
e813d15c-560f-4249-b0c0-a045ae4b68e9	Adoração	Rei Do Universo	Ouvir E Crer	2026-01-28 02:50:13.505435+00	a42f4b94-236e-43d7-abea-e13b2578984e
aa13e2b6-bfd1-42df-9863-d719fbb35f4f	Adoração	Lança Sobre Mim Teu Olhar	Ouvir E Crer	2026-01-28 02:50:13.505435+00	a42f4b94-236e-43d7-abea-e13b2578984e
dbb04368-3eb1-4c11-b142-e8eb320fc287	Adoração	Sonhos	Clamor Pelas Nações	2026-01-28 02:50:13.505435+00	a42f4b94-236e-43d7-abea-e13b2578984e
00fd01e4-e5b8-4241-8cb7-f42382c180de	Adoração	Único Desejo	Deigma Marques	2026-01-28 02:50:13.505435+00	a42f4b94-236e-43d7-abea-e13b2578984e
e37df59b-6da0-403a-b299-e176ea422ba4	Celebração	Luz Do Mundo	Fernandinho	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
9ddae1c7-0e1c-4ad9-998f-c81d7ea1ea96	Celebração	Meu Alvo	Kleber Lucas	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
5b9f1da0-e349-4b3c-b196-3489087c43d3	Celebração	Aquele Que Está Feliz	Comunidade De Nilópolis	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
6cfe03c3-77c7-4ccd-bbf0-3a1f165a3db7	Celebração	Espírito Enche A Minha Vida	Quatro Por Um	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
4357d555-2359-485e-96c0-1ef9a138451f	Celebração	Autoridade É Poder	Alex Gonzaga	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
afb5089d-388f-46c7-b12e-798cbcdb37f2	Celebração	Teu Amor Não Falha	Templo Soul	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
ebbfe11d-c70f-4a47-b377-99e39b829811	Celebração	Deus Não Está Morto	Fernandinho	2026-01-28 02:51:43.778622+00	5b16c5a0-3b1c-4433-bbea-000e3e8849f5
c25c2c36-3996-451f-a184-dd797f400055	Celebração	Celebrai A Cristo, Celebrai	Min. Koinonya De Louvor	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
1be3fb08-f194-466d-8069-bfca1236af67	Celebração	Faço O Melhor	Filhos Do Homem	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
d4c646e0-bf1d-4fa8-920d-ff306db06ee9	Adoração	Tú És Bom	Fred Arrais	2026-01-28 02:53:09.029896+00	4a909e09-0ac4-4526-868d-2482658955f5
32a333a3-ed5b-4b68-bbe5-200ac1ab0149	Adoração	Atos 2	Gabriela Rocha	2026-01-28 02:53:09.029896+00	4a909e09-0ac4-4526-868d-2482658955f5
c35886bf-d3ce-442e-8889-af174ae6a3ba	Adoração	Ousado Amor	Isaías Saad	2026-01-28 02:53:09.029896+00	4a909e09-0ac4-4526-868d-2482658955f5
f19975d1-08e9-4fc3-b247-309286007009	Adoração	Me Ama	Ana Paula Valadão	2026-01-28 02:53:09.029896+00	4a909e09-0ac4-4526-868d-2482658955f5
7b3c1987-e4e0-4db4-a59b-edb0fb1967a7	Adoração	Único	(Part. Marco Telles) Florianópolis House Of Prayer	2026-01-28 02:53:30.903204+00	ece5eaca-f728-43ad-a2dc-1937c4b48b4e
f3a60791-22c3-4b75-aca5-400138ca9614	Adoração	O Grito	Pedras Vivas	2026-01-28 02:53:30.903204+00	5b16c5a0-3b1c-4433-bbea-000e3e8849f5
754bc305-9bfd-4417-a30b-6e9df818b106	Adoração	Isaías 9	Rodolfo Abrantes	2026-01-28 02:53:30.903204+00	ece5eaca-f728-43ad-a2dc-1937c4b48b4e
1806a78b-ffdd-45de-8253-a6d078bd9061	Adoração	Seu Sangue	Fernandinho	2026-01-28 02:53:30.903204+00	5b16c5a0-3b1c-4433-bbea-000e3e8849f5
aad64382-b52e-40d9-b60f-b85396f9788f	Adoração	Quem É Esse?	Julliany Souza	2026-01-28 02:53:30.903204+00	4a909e09-0ac4-4526-868d-2482658955f5
fde897e2-9a6b-42d4-8749-e94f3acf71f1	Adoração	Basta O Som Da Tua Voz	Min. Intensidade Do Leão	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
c90f6b00-b179-4f4a-ae8c-186c8456c7e3	Adoração	Aqui Como No Céu	Drops E Rafael Bicudo	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
136343bb-05a7-463b-94c4-d5106ed4dfce	Adoração	Arde Outra Vez	Thalles Roberto	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
7bf34c43-a1ff-4dd7-85f8-363e77958cb4	Adoração	Árvore Cortada	Valesca Mayssa	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
ab52d03e-c6f9-45b1-a866-2369eac5279d	Adoração	Até Que De Mim Não Sobre Nada	Neylando	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
560f125a-7575-400a-85c9-f9c20bd97064	Adoração	Atrai Meu Coração	Filhos Do Homem	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
a7f88720-7200-47f8-9388-b574956cd4e4	Adoração	Avivamento	Bruno Roques	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
b36966fe-6482-455c-91bc-fa8157cf9d18	Adoração	Boa Obra	Valesca Mayssa	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
7b753f6b-bea5-4ef9-9015-0b321d10b8d2	Adoração	Bom Samaritano	Anderson Freire	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
9a5875e2-01ba-46cc-ac48-c7473ee8e0a0	Adoração	Cadeias Quebrar	Soraya Moraes	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
1870c030-ee89-484c-93fb-e7f52493dde5	Adoração	Caminho No Deserto	Soraya Moraes	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
9040ba88-465a-4866-826d-c992a5af70a4	Adoração	Canção Ao Cordeiro	Israel Salazar E Gabriel Guedes	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
5f7e8002-2fa9-427e-84a2-54dcf46de98f	Adoração	Canção De Jó	Fred Arrais	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
31c3ea33-cfb7-4dc3-9442-12e85db14455	Adoração	Canção De Maria	Mateus Brito	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
65af1e97-421f-4372-958c-21ce05a5571a	Adoração	Canção De Simeão	Drops	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
53ea41c4-df72-41fc-b2ef-8d07b18ae078	Adoração	Canção Do Apocalipse	Diante Do Trono	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
8b91e960-84d2-4332-8f4d-82ed21ede5f6	Adoração	Coração De Mãe	Aline Barros	2026-01-28 02:55:33.388217+00	a42f4b94-236e-43d7-abea-e13b2578984e
8c819b5a-a80c-4771-9f3a-d7e837174d73	Adoração	O Que Tua Glória Fez Comigo	Min. Voz De Muitas Águas	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
f9ff0069-8e26-4dad-96bf-b1abfc9f15d2	Adoração	Última Chance	Min. Ipiranga	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
0b5eb783-dc04-4345-9e08-2dc7de5771d4	Adoração	Creio Em Ti	Min. Zoe	2026-01-28 02:44:17.366572+00	a42f4b94-236e-43d7-abea-e13b2578984e
9a571f31-f12c-48b8-944e-2464d5a4733b	Adoração	No Silêncio	Min. Zoe	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
71fd8a9c-6d6a-4bb6-96f8-522153b40d15	Adoração	Já Posso Ver	Min. Pra Tua Gloria	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
d9b43b75-254f-4177-9c84-4183d703ab0b	Adoração	Deus Do Impossível	Min. Apascentar	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
f365efd2-cab4-4db3-9573-bafa4e3d5621	Adoração	Santidade	Aline Barros	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
dc4d25b1-0350-4bef-83a6-1677af52763a	Adoração	Essência Da Adoração	David Quinlan	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
4ecd38db-e512-4186-a0e9-621cb5b7ae4e	Adoração	Não A Ninguém Como Tu	David Quinlan	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
ce79344a-ecbd-41c7-b9ef-dbc4fc6dc317	Adoração	Como Eu Te Amo	One Sounds	2026-01-28 02:44:17.366572+00	a42f4b94-236e-43d7-abea-e13b2578984e
eb3f0069-cd89-489d-a2a7-823dfa56f253	Adoração	Compromisso	Régis Danese	2026-01-28 02:44:17.366572+00	a42f4b94-236e-43d7-abea-e13b2578984e
0983b4a5-14ef-42c0-98ff-94653385e681	Adoração	Coração Valente	Anderson Freire	2026-01-28 02:44:17.366572+00	a42f4b94-236e-43d7-abea-e13b2578984e
592f7d9b-1d05-4c0e-bc1c-84dee06c2259	Adoração	De Janeiro A Janeiro	Som E Louvor	2026-01-28 02:44:17.366572+00	a42f4b94-236e-43d7-abea-e13b2578984e
149fd204-fc13-4bf8-a370-00e57e7be67c	Adoração	A Terra Clama	Davi Fernandes	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
8a5fa78a-9c46-4ee3-8815-e99e2d535e9e	Adoração	Tudo Sobre Você	Morada	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
49cb1fc2-d818-4433-8be9-37f897a95738	Adoração	Carpinteiro	Alessandro Vilas Boas	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
1494d67f-adcc-491a-bf20-7247777d7a37	Adoração	Santo	Livres Para Adorar	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
6b05a933-706e-4088-b3a9-b1ceb0804910	Adoração	Pode Morar Aquí	Theo Rubia	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
86e0c362-fd58-4ceb-9398-3d8818ab070b	Adoração	Ser Mudado	Alessandro Vilas Boas	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
32faee22-5052-4bf6-8f9a-6b377fb86439	Adoração	Só Quero Ver Você	Laura Souguellis	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
e56ede63-efb7-4651-8588-46e6ad7d0700	Adoração	Beija-Me Com Tua Glória	Judson De Oliveira	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
f0b54268-bd45-4960-a8ba-6a5a703ae108	Adoração	Estás Aquí	Ouvir É Crer	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
6c0c2565-a603-4e18-a2ba-45e786bafa8c	Adoração	Como Na Primeira Vez	Casa De Davi	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
239c68b2-32f8-4984-be91-89992a30be79	Adoração	Que Ele Cresça	Deigma Marques	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
5b836a43-12f9-4c3f-b89f-405fe6e0ee79	Adoração	Só Quero Tua Presença	Theo Rubia	2026-01-28 02:49:22.63361+00	4a909e09-0ac4-4526-868d-2482658955f5
d73d7eb6-f4e3-4945-8bf2-6b21fef81daa	Adoração	Senhor Te Amor	Tom Molinari	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
e473a027-75de-4f3f-b799-b87568f98d50	Adoração	Seu Amor Me Alcançou	Nic & Rachael Billman	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
e386f5f6-ba3f-4929-b2b5-e699e1ec6236	Adoração	Meu Coração Te Pertence	Salzband	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
956d8d42-aee0-494c-95bf-57292a9a4f48	Adoração	Fogo Em Teus Olhos	Rafael Faleiro	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
fd211a58-3242-429f-b9cd-9c672e78bc2c	Adoração	Teu Reino	Cristo Vivo	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
f67c26d7-03a0-47e4-9cc2-d64859ac9097	Adoração	Eu Provei E Vi	Drops	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
e2a2f4f6-1813-4b59-a06f-0c44d3a0f492	Adoração	Céu E Terra Se Encontram	Davi Fernandes	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
8a3b8f29-2c90-442f-815d-76a55f05bb80	Adoração	Aviva-Nos	Davi Fernandes	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
601a7d94-baec-4492-addf-61e63bd7b6a1	Adoração	Furioso Oceano	Jhonas Serra	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
ef9775c8-afdb-43e9-8e86-cb861acb2257	Adoração	Encontrei O Meu Lugar	Jhonas Serra	2026-01-28 02:49:22.63361+00	a42f4b94-236e-43d7-abea-e13b2578984e
132aac2b-4c0c-432f-b0fc-9b69011c7709	Adoração	Labareda De Fogo	Labareda De Fogo	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
8e8ee0d3-5510-4f93-a213-0d095a91d144	Adoração	Só Quero Queimar	Jhonas Serra	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
9cd68d44-e9f3-4fda-bf87-9697215ba758	Adoração	O Teu Amor Está Ganhando Forma	Drops	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
f2b76219-5b1b-45a3-8276-315e7b4e68e8	Adoração	Sonda-Me	Aline Barros	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
6fb60c1e-ea2c-4389-a299-6e58da3bfa2f	Adoração	Abraça-Me	David Quinlan	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
5348f1cd-ea55-4b45-80d0-f6757f16276f	Adoração	Eu Navegarei	Gabriela Rocha	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
f523ee95-dccd-43e8-a4cd-778e2225cfef	Adoração	Há Um Lugar	Heloisa Rosa	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
04c8357e-906a-4f2f-8266-7ce16bff06a2	Adoração	Jesus É O Caminho	Heloísa Rosa	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
056e9bf4-679a-4126-9dba-c3a3b27f519a	Adoração	Vem Andar Comigo	Heloisa Rosa	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
dbe26825-530d-4116-b3d8-95d7d0fa3770	Adoração	Reina Sobre Mim	Nívea Soares	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
f586230c-aa4f-42ac-8595-e3fb957aae06	Adoração	Me Esvaziar	Nívea Soares	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
d8f85e5f-dd1a-4588-ae04-87fea298cc90	Adoração	Enche Este Lugar	David Quinlan E Nívea Soares	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
6960a9e1-b35c-4dfa-8838-f26b72716bfc	Adoração	Que Amor É Esse?	Clamor Pelas Nações	2026-01-28 02:49:43.489202+00	a42f4b94-236e-43d7-abea-e13b2578984e
f8b20635-7c46-4f78-98d8-c3cae26a0310	Adoração	Canção Da Liberdade	Clamor Pelas Nações	2026-01-28 02:50:13.505435+00	a42f4b94-236e-43d7-abea-e13b2578984e
f0dee7e2-a903-4a37-87d1-84674948f492	Adoração	Quando Estou Em Tua Presença	Clamor Pelas Nações	2026-01-28 02:50:13.505435+00	a42f4b94-236e-43d7-abea-e13b2578984e
10860a51-105a-4650-90a9-59751c6f4ddf	Adoração	Meu Desejo	Clamor Pelas Nações	2026-01-28 02:50:13.505435+00	a42f4b94-236e-43d7-abea-e13b2578984e
66ce1825-f12f-4cc5-8a8e-ddd0208b254c	Adoração	Senhor, Tenho Tanta Fome	Clamor Pelas Nações	2026-01-28 02:50:13.505435+00	a42f4b94-236e-43d7-abea-e13b2578984e
283839db-627e-44f3-b6fd-2cae6d15c8c8	Adoração	Você Não Vai Parar	Samuel Messias	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
2aefb135-c0c8-4f47-b26e-9468e5d8e4c4	Adoração	Maranata	Avivah	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
4cba7470-710f-4b6b-bab3-a8b30f813ae4	Adoração	Deus Proverá	Gabriela Gomes	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
b79ee33d-e876-43e8-81fd-86134943c55e	Adoração	Se Tiveres Fé	Fernandinho É Mariah Santos	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
b818d9ed-cc68-40c4-af4f-1672f68bc92d	Adoração	Deus É Deus	Delino Marçal	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
b09c162d-1514-43c3-ab0a-f46606d926a0	Adoração	Deus De Promessas	Toque No Altar	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
01de789f-8ad2-4f3e-87be-f2f4be89c8b5	Adoração	Creio Que Tu És A Cura	Gabriela Rocha	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
a2b3eb67-6c6f-45bc-b707-abac79dbcffc	Adoração	Todavia Me Alegrarei	Leandro Soares	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
698e2305-84fc-4171-8292-993fe44b31c7	Adoração	Eu Adoro	Judson De Oliveira	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
5ab66c70-4add-49c2-9f14-2394b8f66326	Adoração	Ressuscita-Me	Aline Barros	2026-01-28 02:50:13.505435+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
1a433ae8-4aa0-45af-bb20-21a37841d7bf	Adoração	Escudo	Voz Da Verdade	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
76dc8b5f-b1a9-483f-bcac-703fc92a6e5d	Celebração	Adore	André E Felipe	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
abaacf7a-7d98-4cc2-bd46-2f3406009667	Adoração	Jó	Midian Lima	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
2202d977-b2e9-44e0-9c8c-e2cc38866be3	Adoração	Marca Da Promessa	Davi Sacer	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
bc0a5e1b-f28f-4618-b483-54db371160f0	Adoração	Sobre As Águas	Davi Sacer	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
13ad6841-89ac-4b9b-947d-01e47da858df	Adoração	Rompendo Em Fé	Comunidade Da Zona Sul	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
ac7d2c7f-0c9e-451c-becf-2e2fe51659fe	Adoração	Nunca Pare De Lutar	Ludmila Ferber	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
2d1ce296-d793-4e9c-904b-936e7caa82f3	Adoração	Faz Um Milagre Em Mim	Regis Danese	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
959fc7c9-d957-451d-a463-ec0af00e13b3	Adoração	Tu Podes	Regia Danese	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
9f056682-caf1-434d-82b2-d2122ce3a045	Adoração	Vou Deixar Na Cruz	Kleber Lucas	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
58b92d61-30fa-4f4c-bd3b-3e60e181a2f7	Adoração	Quão Grande É Meu Deus	Soraya Morais	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
85d34d23-31da-4475-9bb7-3cef441a97e5	Adoração	Bendito Serás	Trazendo A Arca	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
5daf2253-bf8c-4905-a7be-37f2d27c1daf	Adoração	Desejo Do Meu Coração	Trazendo A Arca	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
99989131-e8c2-413b-8413-a486040aa78d	Adoração	Meu Milagre	Andre Valadão	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
92d7a430-80c7-433a-8444-9687b659accc	Adoração	Sou Um Milagre	Discopraise	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
56592f6c-74dd-4a58-80e1-1481388dadc0	Adoração	Então É Só Clamar	Quatro Por Um	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
8f84fd86-08d2-4fbb-ad50-c1526798cba8	Adoração	Sopra Espírito	Ludmila Ferber	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
dcab49e6-b43c-4f8c-a8a0-f109d801184a	Adoração	Te Agradeço	Diante Do Trono	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
0930bbdd-c9e6-4029-be94-4cbd600c1272	Adoração	Descansarei	Comun. Evangélica De Maringá	2026-01-28 02:51:05.208781+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
075145ab-9c21-4304-a5ca-ded68db55d63	Adoração	Em Teus Braços	Laura Souguellis	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
c8dc7047-afdc-4fa2-b3c1-32820253e2fa	Adoração	Quarto Secreto	Marquinhos Gomes	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
b24698f5-d01e-464e-84ea-800c351cd8af	Adoração	Vai Passar	Gerson Rufino	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
ed8a963a-3336-4485-a19a-7dd0b103ae72	Adoração	Milagres	Juliano Son	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
dbcfd990-60d3-4141-9aac-532ca611053b	Adoração	Uma Nova História	Fernandinho	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
ba0ac01b-3e7f-4aea-bb08-892b91e1cb99	Celebração	Não Há Limites	Quatro Por Um	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
70c658b5-e66c-48d2-ab98-ca30042b25ac	Celebração	Vou Seguir Com Fé	Kleber Lucas	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
a62f3a00-99c1-43cb-a2d1-6d7cbadcfdad	Celebração	Te Agradeço	Kleber Lucas	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
da8706d6-3adf-4374-becf-3167f4c75cab	Celebração	Toda Sorte De Bênçãos	Trazendo A Arca	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
1b4985be-c116-4e81-ab2d-540aedca5c60	Celebração	Golias Voce Vai Cair	Judson De Oliveira	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
c22373f9-5d8a-4827-984a-cdc087675fea	Celebração	Ainda Que A Figueira	Fernandinho	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
72b30545-1044-47b5-8d52-c4d0b0fdbfbb	Celebração	Nada É Impossível	Quatro Por Um	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
0d9c70fc-4e85-4ade-bc3d-59d031854801	Celebração	Oh Meu Irmãozinho	Thalles Roberto	2026-01-28 02:51:24.402462+00	a42f4b94-236e-43d7-abea-e13b2578984e
c038d0a4-41b7-42f2-bd03-6029e8c65d7f	Celebração	Teu Amor Não Falha	Nívea Soares	2026-01-28 02:51:24.402462+00	a42f4b94-236e-43d7-abea-e13b2578984e
a0d85853-29a6-41fb-a2b0-e3e858621c2d	Celebração	Mil Graus	Renascer Praise	2026-01-28 02:51:24.402462+00	a42f4b94-236e-43d7-abea-e13b2578984e
e458645f-e85d-4a2e-a7bf-e674ac42f0aa	Celebração	Eu Celebrarei	Quatro Por Um	2026-01-28 02:51:24.402462+00	a42f4b94-236e-43d7-abea-e13b2578984e
3f19b467-e28f-4e1d-8cf6-4932d837e432	Celebração	Céu É Meu Lugar	Casa Worship	2026-01-28 02:51:24.402462+00	a42f4b94-236e-43d7-abea-e13b2578984e
cd0c209b-988f-46ac-97ac-ff0769c55419	Celebração	Pedra Na Mão	Discopraise	2026-01-28 02:51:24.402462+00	a42f4b94-236e-43d7-abea-e13b2578984e
65ab411d-4988-4ace-8727-2210c78e96c9	Celebração	Dança Na Chuva	Fernandinho	2026-01-28 02:51:24.402462+00	a42f4b94-236e-43d7-abea-e13b2578984e
084d5516-d7b5-4660-89e3-780b621749c2	Celebração	Som Da Liberdade	Dj Pv	2026-01-28 02:51:24.402462+00	a42f4b94-236e-43d7-abea-e13b2578984e
d61263f0-24f4-4009-90e7-c36294c53fb3	Celebração	Vitória No Deserto	Aline Barros	2026-01-28 02:51:24.402462+00	a42f4b94-236e-43d7-abea-e13b2578984e
fa1520ee-f935-494f-8a72-c1a716049acb	Celebração	Eu Me Alegrarei	Judson De Oliveira	2026-01-28 02:51:24.402462+00	a42f4b94-236e-43d7-abea-e13b2578984e
6c7d191c-45c4-428b-8827-adc2f8a1bedc	Celebração	Nosso General É Cristo	Corrinhos Evangélicos	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
0e03e429-06ba-4f5c-9743-793ec0468ddc	Adoração	Raridade	Anderson Freire	2026-01-28 02:51:05.208781+00	46f56494-3dd8-4722-ac40-ee5f2983e1b8
2da6d5b5-96d2-42fe-b5af-fb1e06ff5110	Celebração	Vamos Celebrar	Banda Som E Louvor	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
c756c441-562a-4a63-a39a-ee3962f3de19	Celebração	Adore	Banda Som E Louvor	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
e49fd9c7-3680-4663-af83-fa09f84a8988	Celebração	Todo Mundo Pulando	Fernandinho	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
9bb92a1d-e8dd-4a7d-8ad4-1addaf38d7a3	Celebração	Ja Caíram As Cadeias	Judson De Oliveira	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
0cafda14-bf6d-4ce0-944b-ff75d3fedd53	Celebração	Cheiro De Liberdade	Judson De Oliveira	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
a2c57c44-e44b-4ab5-82a2-af92e070fb95	Celebração	Pes Incendiados	Judson De Oliveira	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
652556bf-5f25-48e2-ae14-2320830e32d7	Adoração	Sobrevivi	Sarah Farias	2026-01-28 02:51:43.778622+00	46f56494-3dd8-4722-ac40-ee5f2983e1b8
f83a9acf-90bd-436c-9020-20bb1b74f085	Adoração	O Mapa Do Tesouro	Gisele Nascimento	2026-01-28 02:51:43.778622+00	46f56494-3dd8-4722-ac40-ee5f2983e1b8
26602a56-c7f7-4108-b84e-566a426b16b5	Adoração	Sou Um Milagre	Voz Da Verdade	2026-01-28 02:51:43.778622+00	46f56494-3dd8-4722-ac40-ee5f2983e1b8
0739f6a5-0646-4782-ba72-1bbd9fb682cf	Adoração	Pra Que	Voz Da Verdade	2026-01-28 02:51:43.778622+00	46f56494-3dd8-4722-ac40-ee5f2983e1b8
26eb5004-962a-45af-971f-83c37793b43a	Adoração	O Escudo	Voz Da Verdade	2026-01-28 02:51:43.778622+00	46f56494-3dd8-4722-ac40-ee5f2983e1b8
92a423c2-1e5b-4005-bd8d-f80ef6e949fe	Adoração	Quero Conhecer Jesus	Alessandro Vilas Boas	2026-01-28 02:51:43.778622+00	a42f4b94-236e-43d7-abea-e13b2578984e
3fdc5f7f-1389-4bec-9ce6-763c05744734	Adoração	Santo Pra Sempre	Felipe Rodrigues	2026-01-28 02:52:48.603008+00	a42f4b94-236e-43d7-abea-e13b2578984e
74ed51a2-2da3-4275-9237-c8247e6f45e4	Adoração	Até Que Ele Venha	Thamires Garcia	2026-01-28 02:52:48.603008+00	a42f4b94-236e-43d7-abea-e13b2578984e
11f9eb01-df18-43d1-8948-ff45435db1da	Adoração	É Ele	Drops	2026-01-28 02:52:48.603008+00	46f56494-3dd8-4722-ac40-ee5f2983e1b8
20614b21-8758-4616-87cb-cf9aa95af2f9	Celebração	Moisés	Fernandinho	2026-01-28 02:52:48.603008+00	a42f4b94-236e-43d7-abea-e13b2578984e
83a813a6-af7c-4d52-bb8b-7500830d6b84	Adoração	O Filho Do Homem	Gilmar Britto	2026-01-28 02:52:48.603008+00	a42f4b94-236e-43d7-abea-e13b2578984e
5ad74905-388c-4a90-a42f-fea67b3085f0	Celebração	Reina O Senhor	Nívea Soares	2026-01-28 02:52:48.603008+00	a42f4b94-236e-43d7-abea-e13b2578984e
ca930119-1e78-4031-98cc-b29acd8239d4	Celebração	Infinitamente Mais	Fernandinho	2026-01-28 02:52:48.603008+00	a42f4b94-236e-43d7-abea-e13b2578984e
2696231e-3a66-4660-9b94-c68e370cd6e4	Adoração	Quero Mais	Theo Rubia	2026-01-28 02:52:48.603008+00	a42f4b94-236e-43d7-abea-e13b2578984e
08727bc8-ce4d-4829-98c5-b90fe0b602bb	Celebração	Estou Sem Fôlego	Pr. Jason Lee Jones	2026-01-28 02:52:48.603008+00	a42f4b94-236e-43d7-abea-e13b2578984e
f82ecb60-a05b-4f5f-b05a-d4f46b2af6b0	Celebração	Se Se Não For Pra Te Adorar	Fernandinho	2026-01-28 02:52:48.603008+00	a42f4b94-236e-43d7-abea-e13b2578984e
c5a3051c-611c-4e13-aecf-550c6945942c	Adoração	Yeshua	Jose Jr	2026-01-28 02:52:48.603008+00	4a909e09-0ac4-4526-868d-2482658955f5
c7f72677-7cc7-4f57-89d2-f483ccdfb4ac	Celebração	Eu Vou Viver Uma Virada	Min. Toque No Altar	2026-01-28 02:51:24.402462+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
e42dbf5e-437a-4001-84e3-6be8aa718e1b	Adoração	Queima De Novo	Colo De Deus	2026-01-28 02:52:48.603008+00	a42f4b94-236e-43d7-abea-e13b2578984e
2415a28c-2d8d-4a03-938f-db24d3d8b871	Adoração	Vitorioso És	Felipe Rodrigues	2026-01-28 02:52:48.603008+00	ece5eaca-f728-43ad-a2dc-1937c4b48b4e
b68f9820-0036-4e7c-8309-ac8562d7809a	Adoração	Poderoso Deus Eterno	Somos Brasas	2026-01-28 02:52:48.603008+00	ece5eaca-f728-43ad-a2dc-1937c4b48b4e
7323f3f5-6252-4485-949d-cf76a9bab6d9	Adoração	Maranata	Alessandro Vilas Boas	2026-01-28 02:52:48.603008+00	4a909e09-0ac4-4526-868d-2482658955f5
ce6114bc-ba3f-4e1b-8a7a-067d28945dd5	Adoração	Faz Outra Vez	Casa De Davi	2026-01-28 02:52:48.603008+00	4a909e09-0ac4-4526-868d-2482658955f5
bb32a4f0-e42d-4225-8d24-c9c9f812382b	Adoração	Digno De Tudo	Fhop	2026-01-28 02:52:48.603008+00	ece5eaca-f728-43ad-a2dc-1937c4b48b4e
58e46339-432b-4c05-af57-175f4c874f17	Adoração	Liberta-Me De Mim	Luna Elpido	2026-01-28 02:52:48.603008+00	4a909e09-0ac4-4526-868d-2482658955f5
37143dd9-b219-4473-9dcd-4ce03926ce91	Adoração	Além Do Impossível	Felipe Rodrigues	2026-01-28 02:52:48.603008+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
a3be98d1-83ef-4db5-b7aa-ffc83c99e97e	Adoração	Jeová Jireh	Aline Barros	2026-01-28 02:52:48.603008+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
19e64dda-fc28-4882-ac7d-b49f6b508795	Adoração	Deserto	Maria Marçal	2026-01-28 02:52:48.603008+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
dd5fcae3-3126-4373-99d8-be09dd65cbb5	Adoração	Preso A Ti	Ton Molinari	2026-01-28 02:53:09.029896+00	ece5eaca-f728-43ad-a2dc-1937c4b48b4e
5d4145f5-90bd-4569-9058-0448e6790dc4	Adoração	Santo Pra Sempre/ Te Exaltamos	Jadson Moreno	2026-01-28 02:53:09.029896+00	ece5eaca-f728-43ad-a2dc-1937c4b48b4e
307d9fa6-548e-43d7-9b57-e2407c43c19a	Adoração	Saudades	Felipe Rodrigues	2026-01-28 02:53:09.029896+00	4a909e09-0ac4-4526-868d-2482658955f5
41724381-e3b3-46eb-85b8-f6da94b4ba76	Adoração	O Fogo Arderá	Alexsander Lúcio	2026-01-28 02:53:09.029896+00	4a909e09-0ac4-4526-868d-2482658955f5
8f8e9b24-2a17-4784-9d3d-cfa5a6898ef1	Adoração	Jesus Meu Primeiro Amor	Fernanda Brum	2026-01-28 02:53:09.029896+00	4a909e09-0ac4-4526-868d-2482658955f5
9d195e90-967e-4b2d-a737-ae2abcb0d810	Adoração	Escape + Com Muito Louvor	Gabriell Junior	2026-01-28 02:53:09.029896+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
dd301f99-9901-4fd7-b680-88da59481a52	Adoração	Não Pare	Midian Lima	2026-01-28 02:53:09.029896+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
912fa55b-91fb-4021-9fa0-fa8902c8abfb	Adoração	Pra Sempre	Fernandinho	2026-01-28 02:53:09.029896+00	ece5eaca-f728-43ad-a2dc-1937c4b48b4e
577fae75-ab3a-4e4f-a2ac-0686375662a2	Adoração	Escape	Jadson Moreno	2026-01-28 02:53:09.029896+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
f1f3256e-d13d-43aa-84b6-a9c8be3421dd	Adoração	Nada Além Do Sangue / Porque Ele Vive	Felipe Rodrigues	2026-01-28 02:53:09.029896+00	5b16c5a0-3b1c-4433-bbea-000e3e8849f5
48f1c81d-47fe-4a46-91a9-e1d157a98b3c	Adoração	Yeshua	Fernandinho	2026-01-28 02:53:09.029896+00	a42f4b94-236e-43d7-abea-e13b2578984e
e782e2a2-d322-42d3-928d-09a2939f2fd6	Adoração	Conversão / Mensagem Da Cruz	Gabriell Junior	2026-01-28 02:53:09.029896+00	5b16c5a0-3b1c-4433-bbea-000e3e8849f5
c0f8ebaa-0b8d-4239-aa27-6e2ab09e39e0	Adoração	Hino Da Vitoria	Cassiane	2026-01-28 02:53:09.029896+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
335866ff-24ea-413c-8d6e-18e4e0ce80eb	Adoração	A Cura	Cassiane	2026-01-28 02:53:09.029896+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
97ebdc0a-f2c1-4bf6-a9aa-d4bd8203a17f	Adoração	Bondade De Deus	Isaías Saad	2026-01-28 02:53:09.029896+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
e12637d4-b9db-48c2-91e9-eea8c4a31809	Adoração	Me Ama	José Jr	2026-01-28 02:53:09.029896+00	4a909e09-0ac4-4526-868d-2482658955f5
e3136a80-8e4a-48cd-a7f9-263a2b100db7	Adoração	Palavras	Lauriete	2026-01-28 02:53:09.029896+00	a42f4b94-236e-43d7-abea-e13b2578984e
df4d1844-c723-46c4-b995-a3ef1390446e	Adoração	João 20 + Pra Sempre + Por Que Ele Vive	Vitor Santana	2026-01-28 02:53:09.029896+00	5b16c5a0-3b1c-4433-bbea-000e3e8849f5
87fd4972-08a6-4862-884d-f2d58ca25f82	Adoração	Corpo E Família	Eli Soares	2026-01-28 02:52:48.603008+00	1578d778-ef09-487f-9e05-3f893a6a98dd
8b8076d6-ffae-4524-a879-f9bedaa14f9c	Adoração	Yahweh Se Manifestará	Marcos Freire	2026-01-28 02:53:30.903204+00	ece5eaca-f728-43ad-a2dc-1937c4b48b4e
e60ab2fd-3388-4342-a431-c557202895e9	Adoração	Tu És	Fhop	2026-01-28 02:53:30.903204+00	4a909e09-0ac4-4526-868d-2482658955f5
dc0fd5ca-41c8-4a05-b783-c7b3a2357c68	Adoração	Jesus	Arianne	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
5b650447-7c6b-458b-bd3c-7bb89945d21a	Adoração	Agradeço	Kleber Lucas	2026-01-28 02:53:30.903204+00	7f4ffc68-3a3c-4a37-8e20-b75643076331
db4fb562-8ace-470e-a9bc-2da8b37960e7	Adoração	Caia Fogo	Fernandinho	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
610ff0c6-27e1-409f-a8c4-bff77e143809	Adoração	Eu Vou Construir	Israel Salazar	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
40c1a129-1579-4905-88a6-86cdcbe0d9b8	Adoração	Oh Quão Lindo Esse Nome É	Ana Nóbrega	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
2770020c-d583-4072-8505-8f19bf88ab70	Adoração	Rendido Estou	Aline Barros	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
2d7849ef-b4a7-45ae-b026-1d78d4f00170	Celebração	Grato Sou	Drops	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
6cbb8f77-d1eb-4448-a8ae-d3f4b93e4acf	Celebração	Tremenda Graça	Drops	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
51e04875-60b0-4204-b014-65947482cb03	Adoração	Já Estou Crucificado	Fernandinho	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
58601d0e-17b0-449d-8557-ec9912f91a30	Celebração	Tremenda Graça	Fred Arais	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
883a0b53-af23-4cc4-9cf6-92a8bc52b6fc	Adoração	500 Graus	Cassiane	2026-01-28 02:53:30.903204+00	a42f4b94-236e-43d7-abea-e13b2578984e
fa895b9d-ec25-4acf-acb3-c2d58b87fde6	Adoração	A Alegria Do Senhor	Fernandinho	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
1bc1a5c1-0e68-4725-a3bc-461870e87121	Adoração	A Alegria Do Senhor	Theo Rubia E Felipe Vilela	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
e8bb3b92-8e46-4fea-93f8-4887068cde33	Adoração	A Benção	Gabriel Guedes E Nívea Soares	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
ca034f37-d930-447a-97b4-854aac9c9d7b	Adoração	A Casa É Sua	Casa Worship	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
63140472-b1e8-40e0-a28c-5bc7506a5bfb	Adoração	A Família E A Marca	Léa Mendonça	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
1c8ca3ca-9e3b-4e88-855a-58ebe0235a75	Adoração	A Minha Esperança	Quatro Por Um	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
78c82442-6b96-4e0d-9a22-af19a47d219b	Adoração	A Presença Da Glória	Antônio Cirilo	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
eb2e93a6-7b42-49f0-9099-bae890d4078c	Adoração	A Tua Mesa Cura	Thamires Garcia	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
7e9f0e44-61ec-4004-a272-7d67efe7ee5b	Adoração	Aba	Laura Souguellis	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
b1585282-d997-4599-87f8-eb2d170029ad	Adoração	Abba, Teu Amor Nunca Falha	Marcos Brunet	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
7931c847-3029-4bc0-9a8f-67be62e6d9b6	Adoração	Abra Os Meus Olhos	Davi Passamani	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
30b8fa80-baf3-439a-8f66-83376e9b0396	Adoração	Abra Os Olhos Do Meu Coração	David Quinlan	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
2287c289-c828-4cec-ba9d-d2f786045cf6	Adoração	Abraça-Me	André Valadão	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
72ae1524-db62-4f5a-9304-6b7d7af5e485	Adoração	Acende O Fogo	Fernandinho	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
a7f6c59d-16af-44d7-93b2-b6fdf680abc5	Adoração	Acende Outra Vez	Jefferson & Suellen	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
87f8c14b-c836-4b3c-beec-cf3490b12cec	Adoração	Advogado Fiel	Bruna Karla	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
0bb3f6f6-6ceb-4bc4-a236-72a2dc9f6f1c	Adoração	Agnus Dei	David Quinlan	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
ed0f8835-2a3f-4a2f-bdbc-9d91e7538d09	Adoração	Águas Profundas	David Quinlan	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
6302e439-e4a8-47ce-92c9-d41c0657d474	Adoração	Águas Purificadoras	Diante Do Trono	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
76c21ed6-1487-45b3-bde6-37c0185630e5	Adoração	Aleluia (Hallelujah)	Gabriela Rocha	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
aa72ba9b-c42f-4b5d-9d06-6ad7fdd6314e	Adoração	Alfa E Ômega / Pra Te Adorar	Gabriela Rocha	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
9c5aad66-2d03-482e-831b-a4b2414efffc	Adoração	Algo Novo	Kemuel (Part. Lukas Agustinho)	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
5ad4c97b-98be-4777-b171-c3abf480afeb	Adoração	Alto Preço	Asaph Borba	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
86611e1d-1d53-4a51-8c11-01cc171dcb1d	Adoração	Amar Como Você	José Augusto (Five Music)	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
503e4e25-46c2-4fb1-b4e8-7d4d315885d9	Adoração	Ambiente De Glória	Reuel E Dany	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
a193264e-32af-4035-b026-fa147c1cd47b	Adoração	Amo O Senhor	Fernanda Brum	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
c2df3378-2c6e-4871-aa5e-1711bb5a1da2	Adoração	Amor De Muitos Se Esfriou	Jose Wellington	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
16bce51e-8106-496b-b567-a64ef0671712	Adoração	A Alegria Está No Coração	Corinhos Evangélicos	2026-01-28 02:55:03.014637+00	a42f4b94-236e-43d7-abea-e13b2578984e
548be1e4-3544-4379-bc57-d8df62f710a6	Adoração	Anjos De Deus (Part. Padre Marcelo Rossi)	Sérgio Reis	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
dc416424-0706-4e24-b3c2-8b1640f77c73	Adoração	Ao Que Está Assentado Sobre O Trono	Davi Fernandes	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
927e5a04-a6c2-4170-810c-f8d8071ff740	Adoração	Ao Único Que É Digno	Jelb	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
1a7350a7-d7de-489a-a3b0-eb890f99a192	Adoração	Aos Pés Da Cruz	Kleber Lucas	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
331926b0-2112-4da5-8966-d8566c58ad66	Adoração	Aqueça Meu Coração	Davi Passamani	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
0943cc55-73cc-4ca6-93ef-3159dc40b70a	Adoração	Aqui Com Você	Sálvaon	2026-01-28 02:55:21.47762+00	a42f4b94-236e-43d7-abea-e13b2578984e
00505dd9-158d-4f14-87b2-1a3345e299e2	Adoração	Canção Do Céu	Anderson Freire	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
478b0ab8-4c2d-4568-a853-52527ac23468	Adoração	Canção Que Não Envelhece	Julliany Souza E Lukas Agustinho	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
4eba8f3c-63dd-4b48-93f2-dcbbb9ed2153	Adoração	Casa Do Pai	Thalles Roberto	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
23f5d9b5-a763-4f79-8c12-349d1163544c	Adoração	Chamado	Judson Oliveira	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
26dcf013-8eda-4f97-9f31-bbfb84c5a326	Adoração	Cidade Vermelha	Tabernáculos	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
596f4d35-b58b-4abf-8a5a-2cbae72ceea1	Adoração	Clamo Jesus	Paulo César Baruk E Marsena	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
9b795fea-8cdd-4919-a7a6-48ffc54194dc	Adoração	Colado A Ti	Rafael Silva	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
0dd04366-0104-47cf-87a9-bbc4fbadc1ae	Adoração	Colossenses	Projeto Sola	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
39282909-97b9-4f2c-b53f-c9077d5267a1	Adoração	Com Muito Louvor	Cassiane	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
8178feed-4860-45df-b3fe-cbb719827444	Adoração	Confio Em Ti	Davi Sacer	2026-01-28 02:55:33.388217+00	a42f4b94-236e-43d7-abea-e13b2578984e
7636b843-10da-4fe6-91f0-388499deea6d	Adoração	Consagração	Aline Barros	2026-01-28 02:55:33.388217+00	a42f4b94-236e-43d7-abea-e13b2578984e
ec070dc7-0ccb-4073-a3c9-a8e0dc3fa2ff	Adoração	Conversão	Harpa Cristã	2026-01-28 02:55:33.388217+00	a42f4b94-236e-43d7-abea-e13b2578984e
3ce42727-f83d-4161-8c23-ede396769af0	Adoração	Cordeiro Santo	Filhos Do Homem	2026-01-28 02:55:33.388217+00	a42f4b94-236e-43d7-abea-e13b2578984e
268378cc-d6a6-4c3f-9c43-0d4bc8c71f15	Celebração	Celebrai	Marcos Góes	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
ffc56ade-de5c-48a5-afb7-edc2b1b3fbdc	Celebração	Celebrai Com Júbilo Ao Senhor	Corinhos Evangélicos	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
3b4ce746-a9b7-40bd-98a4-8ec48be508ff	Celebração	Celebrarei	Cassiane	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
9136e35e-7f6f-4c57-8012-cfcf059a7caa	Adoração	De Volta Pra Casa	Judson De Oliveira	2026-01-28 02:55:33.388217+00	a42f4b94-236e-43d7-abea-e13b2578984e
d4ba3d48-aff3-4588-8d73-b69f43ba838f	Adoração	Além Do Rio Azul	Voz Da Verdade	2026-01-28 02:55:21.47762+00	46f56494-3dd8-4722-ac40-ee5f2983e1b8
2063fa19-c128-47e0-b9ab-175ac3034ec3	Adoração	Até Que Ele Venha	Thamires Garcia Ministério Zoé	2026-01-28 02:53:09.029896+00	e093616a-2319-4315-b391-d42da32dfbd5
8f5d6789-b45a-4c32-9c8c-5c9e320bac44	Adoração	Liberta	Me De Mim	2026-01-30 03:18:25.365159+00	a42f4b94-236e-43d7-abea-e13b2578984e
11fb46e9-517c-4219-8c76-b65c872d03c5	Adoração	Abra Os Olhos Do Meu Coração	David Quilan	2026-01-30 03:18:25.365159+00	a42f4b94-236e-43d7-abea-e13b2578984e
b7c3c48f-4db3-4e37-bd3f-a72cec69f9f8	Adoração	Único	Fhop	2026-01-30 03:18:25.365159+00	a42f4b94-236e-43d7-abea-e13b2578984e
f74bfd9e-6804-4f04-a2a2-f4d83bc56695	Adoração	Como Árvore	Min. Voz De Muitas Águas	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
bae88b98-f7bb-47df-b506-65855a171e30	Adoração	Como Prometestes	Min. Voz De Muitas Águas	2026-01-28 02:55:33.388217+00	a42f4b94-236e-43d7-abea-e13b2578984e
f80cd18b-8f51-4877-8fd5-b5d8327515af	Adoração	Coração Igual O Teu	Diante Do Trono	2026-01-28 02:55:33.388217+00	a42f4b94-236e-43d7-abea-e13b2578984e
35204e5d-32c8-42c4-bb9a-23d17923cfb1	Adoração	Carta Viva	Min. Intensidade Do Leão	2026-01-28 02:55:32.587445+00	a42f4b94-236e-43d7-abea-e13b2578984e
\.


--
-- Data for Name: tons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tons" ("id", "created_at", "nome_tons", "descricao_tons") FROM stdin;
1	2026-01-28 21:26:22.454419+00	C - Am	Dó ou Lá Menor
2	2026-01-28 21:26:22.454419+00	C# - A#m	Dó Sustenido ou Lá Sustenido Menor
3	2026-01-28 21:26:22.454419+00	D - Bm	Ré ou Si Menor
4	2026-01-28 21:26:22.454419+00	D# - Cm	Ré Sustenido ou Dó Menor
5	2026-01-28 21:26:22.454419+00	E - C#m	Mi ou Dó Sustenido Menor
6	2026-01-28 21:26:22.454419+00	F - Dm	Fá ou Ré Menor
7	2026-01-28 21:26:22.454419+00	F# - D#m	Fá Sustenido ou Ré Sustenido Menor
8	2026-01-28 21:26:22.454419+00	G - Em	Sol ou Mi Menor
9	2026-01-28 21:26:22.454419+00	G# - Fm	Sol Sustenido ou Fá Menor
10	2026-01-28 21:26:22.454419+00	A - F#m	Lá ou Fá Sustenido Menor
11	2026-01-28 21:26:22.454419+00	A# - Gm	Lá Sustenido ou Sol Menor
12	2026-01-28 21:26:22.454419+00	B - G#m	Si ou Sol Sustenido Menor
\.


--
-- Data for Name: historico_musicas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."historico_musicas" ("id", "created_at", "id_membros", "id_tons", "id_musica") FROM stdin;
8cdfb238-a587-4df4-9f22-477e5857ab75	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	3	2da6d5b5-96d2-42fe-b5af-fb1e06ff5110
148a1626-238d-4aa6-abc4-637a6e3b0079	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	10	3fdc5f7f-1389-4bec-9ce6-763c05744734
b6a7c154-8494-4596-8ae0-7c77b70fecda	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	5	e42dbf5e-437a-4001-84e3-6be8aa718e1b
84167973-91be-428c-8261-c9ce34d1ade4	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	12	bb32a4f0-e42d-4225-8d24-c9c9f812382b
f32f070c-d56c-4b82-978b-a6df19a27fe0	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	1	bb32a4f0-e42d-4225-8d24-c9c9f812382b
cd7c1bf2-2449-4727-8acd-f73bc41c7943	2026-01-27 23:22:40.319431+00	23d2d224-8f94-4e4f-ab13-7e8868e20611	3	37143dd9-b219-4473-9dcd-4ce03926ce91
fb337218-ba98-4e9f-89d9-31b2ebc894fd	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	1	5d4145f5-90bd-4569-9058-0448e6790dc4
52255fbc-2cbc-4ead-bc98-b3944034a5cb	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	912fa55b-91fb-4021-9fa0-fa8902c8abfb
2476d4ed-bd0c-414a-9877-0b0450024e17	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	577fae75-ab3a-4e4f-a2ac-0686375662a2
ead28674-3dc4-44c5-a17b-450dd0015205	2026-01-27 23:22:40.319431+00	2577d100-73c8-4579-9de2-4e76818a027e	11	e782e2a2-d322-42d3-928d-09a2939f2fd6
772cffa3-a570-4185-b6b4-8e63864f5e50	2026-01-27 23:22:40.319431+00	04696c14-57f5-4492-a09d-91a4bd2aea80	3	c0f8ebaa-0b8d-4239-aa27-6e2ab09e39e0
7e064c6c-0841-4e47-b67d-b70254f1bc26	2026-01-27 23:22:40.319431+00	04696c14-57f5-4492-a09d-91a4bd2aea80	3	335866ff-24ea-413c-8d6e-18e4e0ce80eb
322fdef1-8728-4daa-8cbf-19ab381139e9	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	9	97ebdc0a-f2c1-4bf6-a9aa-d4bd8203a17f
494dd4a0-aea8-4691-8e0e-5d526b333937	2026-01-27 23:22:40.319431+00	2577d100-73c8-4579-9de2-4e76818a027e	7	7b3c1987-e4e0-4db4-a59b-edb0fb1967a7
ffa8c741-e4db-422b-87ed-913face4bc91	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	1	1be3fb08-f194-466d-8069-bfca1236af67
bde278ee-c530-4452-8dd1-65c36b47d6b3	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	1	c25c2c36-3996-451f-a184-dd797f400055
c6c84843-9a88-4352-a453-36464a0cec16	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	2d7849ef-b4a7-45ae-b026-1d78d4f00170
856bcb80-8141-4aa0-9c4c-e6380513f046	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	5	2d7849ef-b4a7-45ae-b026-1d78d4f00170
dfd69cd4-5410-4066-a6c8-c75baac43468	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	6cbb8f77-d1eb-4448-a8ae-d3f4b93e4acf
cb236572-a905-477c-8634-ec1740220370	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	51e04875-60b0-4204-b014-65947482cb03
390e6778-7103-4f77-ada1-dc6d229560cb	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	00505dd9-158d-4f14-87b2-1a3345e299e2
ccd55aa4-be60-4945-bcd0-668865075738	2026-01-27 23:22:40.319431+00	2577d100-73c8-4579-9de2-4e76818a027e	3	d4ba3d48-aff3-4588-8d73-b69f43ba838f
9b91f56f-6c8f-45e0-a715-3def16b73c9f	2026-01-27 23:22:40.319431+00	88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	1	8f5d6789-b45a-4c32-9c8c-5c9e320bac44
e604a2f3-baec-4fe0-9da6-9d0ad34470b5	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	11fb46e9-517c-4219-8c76-b65c872d03c5
453c256c-5769-4246-b953-c8ac002f12a2	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	5	0739f6a5-0646-4782-ba72-1bbd9fb682cf
40e2b7f1-785c-48e3-8d92-34097a0af556	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	5	d70d3c73-2f99-4e95-a3e3-475f32de5caf
23630792-3527-4d87-b71f-bc3eb88f1d27	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	2	97ebdc0a-f2c1-4bf6-a9aa-d4bd8203a17f
f80453e9-57c9-4763-9893-8bf91df9f742	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	1	e12637d4-b9db-48c2-91e9-eea8c4a31809
212904ed-20e0-4ae5-a1fb-abdbfe872362	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	3	b7c3c48f-4db3-4e37-bd3f-a72cec69f9f8
cd8e3fbf-3735-4d68-814b-2c7f8f3324e2	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	8	698e2305-84fc-4171-8292-993fe44b31c7
a2364365-7045-4d95-af3b-a7503cb4603b	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	1	c038d0a4-41b7-42f2-bd03-6029e8c65d7f
27f773a4-71a6-4021-acb6-64aafcfa21d4	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	5	6cfe03c3-77c7-4ccd-bbf0-3a1f165a3db7
5c90a5cd-af3d-482b-a4e9-1c11d93e4f17	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	239c68b2-32f8-4984-be91-89992a30be79
9eb46f13-27aa-48c8-b9f4-3be445432088	2026-01-27 23:22:40.319431+00	2577d100-73c8-4579-9de2-4e76818a027e	7	239c68b2-32f8-4984-be91-89992a30be79
34162bce-9207-49ba-a8b9-095ccaa403ba	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	4	8c819b5a-a80c-4771-9f3a-d7e837174d73
6729a966-cf38-461d-bfc0-3da9a9512e54	2026-01-27 23:22:40.319431+00	23d2d224-8f94-4e4f-ab13-7e8868e20611	5	d9b43b75-254f-4177-9c84-4183d703ab0b
451e38be-e7d3-4dcf-ae1d-05ec7fc1e70d	2026-01-27 23:22:40.319431+00	23d2d224-8f94-4e4f-ab13-7e8868e20611	3	d9b43b75-254f-4177-9c84-4183d703ab0b
8902a3b8-af5f-42a2-accc-ed96d040e46c	2026-01-27 23:22:40.319431+00	24d79386-6eea-4478-8f2c-5611192b7a0c	10	01de789f-8ad2-4f3e-87be-f2f4be89c8b5
3b47fc96-27ff-4a59-b1e6-80c61071e392	2026-01-27 23:22:40.319431+00	23d2d224-8f94-4e4f-ab13-7e8868e20611	8	01de789f-8ad2-4f3e-87be-f2f4be89c8b5
a29c7f9c-363d-47ea-9d85-3d0da7a6b271	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	10	a2b3eb67-6c6f-45bc-b707-abac79dbcffc
11c1f94e-7d8e-418e-9eb5-1e546ace6f4b	2026-01-27 23:22:40.319431+00	23d2d224-8f94-4e4f-ab13-7e8868e20611	3	a2b3eb67-6c6f-45bc-b707-abac79dbcffc
5598d551-135b-4c10-8f11-dd2b80a4ee92	2026-01-27 23:22:40.319431+00	88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	5	abaacf7a-7d98-4cc2-bd46-2f3406009667
f6695b42-c8f6-4bec-810d-be163fe8a9c7	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	bc0a5e1b-f28f-4618-b483-54db371160f0
20b01683-fbf8-4881-a1ea-50e84850a581	2026-01-27 23:22:40.319431+00	23d2d224-8f94-4e4f-ab13-7e8868e20611	5	bc0a5e1b-f28f-4618-b483-54db371160f0
e7bc427d-1436-4c2a-87f3-7ca441b4559f	2026-01-27 23:22:40.319431+00	23d2d224-8f94-4e4f-ab13-7e8868e20611	3	075145ab-9c21-4304-a5ca-ded68db55d63
f2a8c78f-1721-428d-9329-7702958cbbae	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	c7f72677-7cc7-4f57-89d2-f483ccdfb4ac
e97ed654-5dc0-4aab-8395-b13e1d7d0f9a	2026-01-27 23:22:40.319431+00	23d2d224-8f94-4e4f-ab13-7e8868e20611	9	c038d0a4-41b7-42f2-bd03-6029e8c65d7f
4a00c541-f6ed-4ec0-953d-972207677dfd	2026-01-27 23:22:40.319431+00	23d2d224-8f94-4e4f-ab13-7e8868e20611	10	a0d85853-29a6-41fb-a2b0-e3e858621c2d
461fb015-15f3-48c4-8049-25d1baa3b707	2026-01-27 23:22:40.319431+00	23d2d224-8f94-4e4f-ab13-7e8868e20611	1	fa1520ee-f935-494f-8a72-c1a716049acb
d34d7c79-5832-4739-8850-f3c0575384df	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	10	6c7d191c-45c4-428b-8827-adc2f8a1bedc
7173a276-eafe-4900-8f55-5794ba14ce63	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	9ddae1c7-0e1c-4ad9-998f-c81d7ea1ea96
b3e45b46-0151-4492-ab1d-142f380a47f9	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	5	ebbfe11d-c70f-4a47-b377-99e39b829811
aca6de38-89b1-4e95-b189-e4af9a6af691	2026-01-27 23:22:40.319431+00	88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	4	f010bf9b-9e6f-46bb-9c8f-93812984164d
6a78682e-1d4c-49c3-bf2a-ea4b9982e553	2026-01-27 23:22:40.319431+00	24d79386-6eea-4478-8f2c-5611192b7a0c	1	3fdc5f7f-1389-4bec-9ce6-763c05744734
5ab5e9de-a93e-4e7f-86a4-1c99e49aa702	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	1	f010bf9b-9e6f-46bb-9c8f-93812984164d
ab0be571-6fb1-43ca-955a-e9f0199996b8	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	1	b68f9820-0036-4e7c-8309-ac8562d7809a
8c53ebc7-2b83-43c5-9706-f58bba649c88	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	1	7323f3f5-6252-4485-949d-cf76a9bab6d9
38e56c6f-c8a8-4bc4-b72d-d83a077e9b97	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	1	dd5fcae3-3126-4373-99d8-be09dd65cbb5
5c39d0a6-9475-4978-a204-81a9e8445909	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	11	f1f3256e-d13d-43aa-84b6-a9c8be3421dd
a1bfd7ac-7a61-48cc-a225-6846d5adf1fd	2026-01-27 23:22:40.319431+00	88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	4	74ed51a2-2da3-4275-9237-c8247e6f45e4
deb042cc-68a4-4f7f-8319-cd8ee5084353	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	11f9eb01-df18-43d1-8948-ff45435db1da
d0fa47f6-8cfe-4584-8240-5e6d4df16829	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	ca930119-1e78-4031-98cc-b29acd8239d4
76732b4d-c2d9-484b-a9ec-f1eae4856a79	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	5	08727bc8-ce4d-4829-98c5-b90fe0b602bb
8363e15e-d5c3-4048-b394-ea9292684548	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	f82ecb60-a05b-4f5f-b05a-d4f46b2af6b0
dba59d6f-7fe1-4429-b10b-3019de09abb2	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	e42dbf5e-437a-4001-84e3-6be8aa718e1b
a734c7de-e6ff-47be-9a7a-191a8bd15af2	2026-01-27 23:22:40.319431+00	24d79386-6eea-4478-8f2c-5611192b7a0c	11	98ff7494-2bc9-48e6-8b49-5bdfddd6477e
fe93d0d6-0c04-403d-b8bf-730eac69e411	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	5	7323f3f5-6252-4485-949d-cf76a9bab6d9
e4410926-1656-4d01-b68a-3fe9396f5e86	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	1	7323f3f5-6252-4485-949d-cf76a9bab6d9
9ef78cf1-08b5-4eb6-b6f2-172d38260141	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	4	ce6114bc-ba3f-4e1b-8a7a-067d28945dd5
a0bc74c0-0d4f-4eaa-93fb-4e8ca7a59529	2026-01-27 23:22:40.319431+00	88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	1	bb32a4f0-e42d-4225-8d24-c9c9f812382b
9d6e3482-35cf-4efd-8b90-bb63d55c9c22	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	5	37143dd9-b219-4473-9dcd-4ce03926ce91
11858ae2-8176-4315-a203-bc4b4e8171ee	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	5	a3be98d1-83ef-4db5-b7aa-ffc83c99e97e
7265f10c-a5be-43c6-b81e-8fd382f8c2e2	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	12	19e64dda-fc28-4882-ac7d-b49f6b508795
ebf8aff3-ef22-4799-9b03-c37eb96d13c6	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	5d4145f5-90bd-4569-9058-0448e6790dc4
307474cf-5842-4284-9be5-10a249e3bca8	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	307d9fa6-548e-43d7-9b57-e2407c43c19a
34351ea6-66b1-4944-a319-11b582c58a88	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	41724381-e3b3-46eb-85b8-f6da94b4ba76
65345949-a13e-4fea-8de4-9b216e13c5d5	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	8f8e9b24-2a17-4784-9d3d-cfa5a6898ef1
7dbf70d9-2e00-4560-b534-a60c2b0dd891	2026-01-27 23:22:40.319431+00	88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	8	9d195e90-967e-4b2d-a737-ae2abcb0d810
bf8f7bb7-b705-4f73-bd32-0df239ae467a	2026-01-27 23:22:40.319431+00	88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	1	dd301f99-9901-4fd7-b680-88da59481a52
ee3718fc-9f7d-45a8-8e06-325f21732925	2026-01-27 23:22:40.319431+00	24d79386-6eea-4478-8f2c-5611192b7a0c	11	912fa55b-91fb-4021-9fa0-fa8902c8abfb
537c1dd4-f931-49c4-a2c1-bfc655b86521	2026-01-27 23:22:40.319431+00	24d79386-6eea-4478-8f2c-5611192b7a0c	8	577fae75-ab3a-4e4f-a2ac-0686375662a2
966e190d-fd2c-4658-8b51-822d0bbba037	2026-01-27 23:22:40.319431+00	2577d100-73c8-4579-9de2-4e76818a027e	1	48f1c81d-47fe-4a46-91a9-e1d157a98b3c
6b63721b-c8ee-4fcb-9081-759728a69c08	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	6	e3136a80-8e4a-48cd-a7f9-263a2b100db7
443bfd91-e0a5-4319-9dfb-d9f3fb5f4217	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	\N	32a333a3-ed5b-4b68-bbe5-200ac1ab0149
aab306c6-d533-41ce-b96a-55d334634afb	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	5	32a333a3-ed5b-4b68-bbe5-200ac1ab0149
5d4c2a7d-66b6-42d2-81e3-d26ecfb4fcaa	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	3	239c68b2-32f8-4984-be91-89992a30be79
597fb56f-362c-498d-b9b3-169dcf0ce333	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	3	fb8c1186-791a-43c6-9802-489cd0cf5da3
ba390954-8709-460e-9392-7851a7f68e0f	2026-01-27 23:22:40.319431+00	e74c904e-6dcd-4536-af23-74401f842f22	1	aad64382-b52e-40d9-b60f-b85396f9788f
e77553c3-33d0-435b-98f2-f49fa540a370	2026-01-27 23:22:40.319431+00	2577d100-73c8-4579-9de2-4e76818a027e	12	9a571f31-f12c-48b8-944e-2464d5a4733b
b94d5995-d0de-47d5-bb93-0c0ff05d0b54	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	e473a027-75de-4f3f-b799-b87568f98d50
2789e0bd-8880-4191-b5aa-74d022b488e7	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	1	b09c162d-1514-43c3-ab0a-f46606d926a0
24d67ca4-5e3f-4c0e-be59-0bcd4e701e6c	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	1a433ae8-4aa0-45af-bb20-21a37841d7bf
3b76aa4e-0a0f-405e-a4ba-0d1fbe4df386	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	78e3cc0f-0390-4a5a-af17-b001449d9200
8029eb91-5f56-41f7-9ae2-0f79c9399996	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	da8706d6-3adf-4374-becf-3167f4c75cab
973dab86-615e-4988-8f33-a7dd6ae430c5	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	c038d0a4-41b7-42f2-bd03-6029e8c65d7f
9baa3de9-66d9-4160-9487-99a7b6df9c40	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	0e03e429-06ba-4f5c-9743-793ec0468ddc
3f455582-9037-4a30-999e-fcf44d798c20	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	ebbfe11d-c70f-4a47-b377-99e39b829811
141acc2c-d133-4c7c-b2b1-c93a65ca7d53	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	912fa55b-91fb-4021-9fa0-fa8902c8abfb
4aca2370-645c-4598-b76c-c988eb325f94	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	12	c35886bf-d3ce-442e-8889-af174ae6a3ba
7f597c69-e521-4389-b4d0-6c8aa67c922c	2026-01-27 23:22:40.319431+00	332c48aa-eb34-452a-971e-5f3dbafad987	1	f19975d1-08e9-4fc3-b247-309286007009
9541d1c9-5340-4e83-9346-60804bdb0fc2	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	9	f19975d1-08e9-4fc3-b247-309286007009
7bb24bc9-1702-4cc0-98cb-73a764f5155d	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	1	f3a60791-22c3-4b75-aca5-400138ca9614
9ec39e9b-2006-41e2-8254-90a9d1203650	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	754bc305-9bfd-4417-a30b-6e9df818b106
784638e5-f031-4e3d-8b52-e1507b97a9b5	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	754bc305-9bfd-4417-a30b-6e9df818b106
7b1bb835-2966-4316-b00a-0ec207c35122	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	3	e60ab2fd-3388-4342-a431-c557202895e9
8d078c9c-ea8c-4f1f-941a-4ad0a926c19d	2026-01-27 23:22:40.319431+00	51306dad-b8e0-46b4-aaa4-24510690a705	3	dc0fd5ca-41c8-4a05-b783-c7b3a2357c68
57cffc71-b2da-4c59-8a2b-8c9b32d0abbb	2026-01-27 23:22:40.319431+00	23d2d224-8f94-4e4f-ab13-7e8868e20611	6	5b650447-7c6b-458b-bd3c-7bb89945d21a
bc964b7c-9e9e-414d-b77f-f0845f1c2bfe	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	db4fb562-8ace-470e-a9bc-2da8b37960e7
4377601b-a311-41c2-b161-f0dbc92967f9	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	610ff0c6-27e1-409f-a8c4-bff77e143809
9789d199-ca5a-4e7b-a35a-03914fcb5774	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	40c1a129-1579-4905-88a6-86cdcbe0d9b8
1f055820-b960-45ed-ac07-eb5b5a07238c	2026-01-27 23:22:40.319431+00	414350c9-e858-4dee-85e4-a93c3a05bced	8	2770020c-d583-4072-8505-8f19bf88ab70
\.


--
-- Data for Name: limpeza; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."limpeza" ("id", "created_at", "foto") FROM stdin;
1	2026-02-01 04:37:03.12862+00	https://ipdrbhkzluuwjulkhjkd.supabase.co/storage/v1/object/public/public-assets/limpeza/status_atual_1770225477667.png
\.


--
-- Data for Name: membros_funcoes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."membros_funcoes" ("id", "id_membro", "id_funcao", "created_at") FROM stdin;
1f3baabd-702a-4a5b-8074-8b5126ce00ed	ee2a4422-b096-47b7-bfbb-541217503bf7	1	2026-01-29 03:49:50.545065+00
5bf9ea49-782a-4124-9869-0f6612194c95	ee2a4422-b096-47b7-bfbb-541217503bf7	2	2026-01-29 03:49:50.545065+00
ceafecfb-ce7f-4438-a9b9-0d129628c1f7	ee2a4422-b096-47b7-bfbb-541217503bf7	3	2026-01-29 03:49:50.545065+00
77f1236f-c5cf-4e9e-8cd4-ec5aa54ed2a6	24d79386-6eea-4478-8f2c-5611192b7a0c	1	2026-01-29 03:49:50.545065+00
947311a3-15d9-4fc5-80b2-515e6f2c9204	24d79386-6eea-4478-8f2c-5611192b7a0c	2	2026-01-29 03:49:50.545065+00
d7358fd9-80db-4b0c-8ace-fac01116c973	e7fae8f4-1411-459b-af01-0eefdaa7e57c	2	2026-01-29 03:49:50.545065+00
092f0452-d157-453a-b868-de48b6db1209	4b543930-107b-4580-b00f-958769fa4400	2	2026-01-29 03:49:50.545065+00
429464c2-394a-42f8-8c6b-a1243e0386f9	18c7dd1b-8347-443d-b439-2bb8579b5386	1	2026-01-29 03:49:50.545065+00
4d254d53-3de5-4d59-97b5-d8d7ac7e270d	18c7dd1b-8347-443d-b439-2bb8579b5386	2	2026-01-29 03:49:50.545065+00
6c9cabd3-034c-464b-a4bc-58b4c15578d9	88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	1	2026-01-29 03:49:50.545065+00
63e07554-dac8-4507-8592-d1fdc349100c	88b364cf-5b9d-43ed-a01d-c7da6ce1e22e	2	2026-01-29 03:49:50.545065+00
408eed73-09ae-4c53-a7fb-29b5e7fc0e87	a1d9f814-46e4-48d4-8262-b3fce5cb0fd6	2	2026-01-29 03:49:50.545065+00
4b86c5f6-409c-4dc7-a977-6e08c5393364	a1d9f814-46e4-48d4-8262-b3fce5cb0fd6	1	2026-01-29 03:49:50.545065+00
4842300f-cea7-43cc-9aa9-5d7569fe7d18	b64a4caa-b645-414e-a213-d3076076922b	7	2026-01-29 03:49:50.545065+00
b4ca62d9-3883-49f6-b6a4-12c21e82c312	96d801f5-58e6-444f-9416-d6817bb47042	4	2026-01-29 03:49:50.545065+00
9544642c-e7d9-408e-b487-feb9726a2704	ec5dc436-f243-49d2-a66b-c114b6811ea0	7	2026-01-29 03:49:50.545065+00
20cf5c99-e070-48ee-9c39-2a500cf1aa1f	6993a591-8905-49e7-a35e-3eda54081713	6	2026-01-29 03:49:50.545065+00
1496decd-42ba-4f5e-9ffc-3470bab12057	6993a591-8905-49e7-a35e-3eda54081713	3	2026-01-29 03:49:50.545065+00
8a332435-9e3c-412d-8de3-6c27c00ec85d	6993a591-8905-49e7-a35e-3eda54081713	2	2026-01-29 03:49:50.545065+00
702c3a7d-88fd-436f-9d3d-8ce43be7ed7c	6993a591-8905-49e7-a35e-3eda54081713	1	2026-01-29 03:49:50.545065+00
3830c4b9-a915-4f28-8684-40aca74ad772	dff6aff0-a4ac-4141-bda1-8e8ffa04cfff	2	2026-01-29 03:49:50.545065+00
e8af2ace-67c2-4761-90a0-58c376c85565	dff6aff0-a4ac-4141-bda1-8e8ffa04cfff	1	2026-01-29 03:49:50.545065+00
76790199-ca36-44b6-9fa0-ba48efc789de	6b269cc2-3352-41b0-9286-52cd423f30e9	1	2026-01-29 03:49:50.545065+00
dc7e889d-9889-42d1-8e41-7587f8c35c5f	6b269cc2-3352-41b0-9286-52cd423f30e9	2	2026-01-29 03:49:50.545065+00
b994296f-6146-427d-a5a7-55046f8f3bfa	6b269cc2-3352-41b0-9286-52cd423f30e9	3	2026-01-29 03:49:50.545065+00
17c69001-91a9-47ce-a9d8-c5af8f22d671	6b269cc2-3352-41b0-9286-52cd423f30e9	4	2026-01-29 03:49:50.545065+00
5c61fc91-d3da-4793-8d96-c7373f6fc212	6b269cc2-3352-41b0-9286-52cd423f30e9	5	2026-01-29 03:49:50.545065+00
0fb78525-e47e-41f0-adc6-1637d822a8eb	6b269cc2-3352-41b0-9286-52cd423f30e9	6	2026-01-29 03:49:50.545065+00
3e3f082c-3b3e-4687-9532-6a592d8a39d8	6b269cc2-3352-41b0-9286-52cd423f30e9	7	2026-01-29 03:49:50.545065+00
5fb13426-b8c0-4a53-99b6-bfb47acf581e	414350c9-e858-4dee-85e4-a93c3a05bced	6	2026-01-29 03:49:50.545065+00
598e6a03-7570-473b-af56-7913c0a2c789	414350c9-e858-4dee-85e4-a93c3a05bced	3	2026-01-29 03:49:50.545065+00
aa31223e-a88a-4845-81e5-50b58384d164	414350c9-e858-4dee-85e4-a93c3a05bced	2	2026-01-29 03:49:50.545065+00
f1c78a80-5e54-43c1-8159-a1df0692e045	414350c9-e858-4dee-85e4-a93c3a05bced	1	2026-01-29 03:49:50.545065+00
7d07e081-b22e-48c1-849d-44e0df632c0d	23d2d224-8f94-4e4f-ab13-7e8868e20611	1	2026-01-29 03:49:50.545065+00
ef7eedb4-3747-48f2-ba58-5ac3b34b27b6	23d2d224-8f94-4e4f-ab13-7e8868e20611	2	2026-01-29 03:49:50.545065+00
027c7e28-7f87-4f25-9800-10d0c3673ffc	23d2d224-8f94-4e4f-ab13-7e8868e20611	3	2026-01-29 03:49:50.545065+00
7abbfaf6-cac6-4437-8625-1a17bf615d9a	23d2d224-8f94-4e4f-ab13-7e8868e20611	6	2026-01-29 03:49:50.545065+00
f4bff1ad-f386-4842-9735-2594ef4be51b	7e79b82c-fc1f-4322-8200-9c371805abe3	6	2026-01-29 03:49:50.545065+00
4b8a0567-5294-48d7-8e84-0feacd442e6c	7e79b82c-fc1f-4322-8200-9c371805abe3	3	2026-01-29 03:49:50.545065+00
d70d33f9-bb0e-4c84-9a4a-e98f1bfd804b	7e79b82c-fc1f-4322-8200-9c371805abe3	2	2026-01-29 03:49:50.545065+00
0ce42cc3-a5a4-4c54-81a2-348fe81d574f	7e79b82c-fc1f-4322-8200-9c371805abe3	1	2026-01-29 03:49:50.545065+00
6833f05e-99e9-40fe-964a-4e133ef0aedd	03a18d33-f884-43a5-a579-162578daac5a	7	2026-01-29 03:49:50.545065+00
1518f0fc-cea2-4acb-8226-a484d44d9dc2	03a18d33-f884-43a5-a579-162578daac5a	3	2026-01-29 03:49:50.545065+00
a13d8d91-64bb-4ad8-9484-71d59ffd8bbe	03a18d33-f884-43a5-a579-162578daac5a	2	2026-01-29 03:49:50.545065+00
b2200c2e-ca9e-4c8f-ae92-4d677552ed82	03a18d33-f884-43a5-a579-162578daac5a	1	2026-01-29 03:49:50.545065+00
daff5c55-9c10-4ea9-bb99-afff07761325	03a18d33-f884-43a5-a579-162578daac5a	4	2026-01-29 03:49:50.545065+00
31f35b58-e614-4357-a7e0-ebdd46f4760b	1563eb41-f8ad-4ff8-a141-778e4e73a288	5	2026-01-29 03:49:50.545065+00
b84ac3c4-e87f-42df-bc31-140d31012c61	1563eb41-f8ad-4ff8-a141-778e4e73a288	3	2026-01-29 03:49:50.545065+00
4e20da41-65a5-49c9-a798-de12572863ac	04696c14-57f5-4492-a09d-91a4bd2aea80	2	2026-01-29 03:49:50.545065+00
d53289d7-e3dd-4b20-a007-e0968c5a0fe7	04696c14-57f5-4492-a09d-91a4bd2aea80	1	2026-01-29 03:49:50.545065+00
2e996747-7a57-4ba9-b811-0f1c3c553524	35be7e54-5d03-4e92-9304-abe4ca3885e8	1	2026-01-29 03:49:50.545065+00
438a3501-a616-4e6a-bd5a-9322d2155639	35be7e54-5d03-4e92-9304-abe4ca3885e8	2	2026-01-29 03:49:50.545065+00
1c9817eb-770b-4cea-9fcf-77f1d5a97044	35be7e54-5d03-4e92-9304-abe4ca3885e8	3	2026-01-29 03:49:50.545065+00
26e3017d-d8a3-4923-9901-9d0ec39f6aee	35be7e54-5d03-4e92-9304-abe4ca3885e8	6	2026-01-29 03:49:50.545065+00
0c4172d1-5220-4ca8-8efd-8783e308cad5	51306dad-b8e0-46b4-aaa4-24510690a705	2	2026-01-29 03:49:50.545065+00
ded0b677-abc2-48c6-9884-201defbb4a78	51306dad-b8e0-46b4-aaa4-24510690a705	1	2026-01-29 03:49:50.545065+00
f09f4fc2-1f85-4474-9656-02d403f1f1dc	332c48aa-eb34-452a-971e-5f3dbafad987	1	2026-01-29 03:49:50.545065+00
ccb41f5c-4de5-430b-a8ef-4f3d4d985d90	332c48aa-eb34-452a-971e-5f3dbafad987	2	2026-01-29 03:49:50.545065+00
3dab2661-6e1b-440b-87b7-ca1a22070e0a	2ee9bbd2-f0e0-4e42-b7ca-a1eba002783b	2	2026-01-29 03:49:50.545065+00
683e2706-d4f9-429c-a219-0889135103f1	49eee164-7639-4d09-9a19-997955cef4d5	1	2026-01-29 03:49:50.545065+00
16467f6a-0dab-47d3-abdb-f7683dac6bb5	49eee164-7639-4d09-9a19-997955cef4d5	2	2026-01-29 03:49:50.545065+00
279936db-3100-451c-9f98-f7933098d84e	2577d100-73c8-4579-9de2-4e76818a027e	1	2026-01-29 03:49:50.545065+00
87d5d025-d4e8-4137-ab58-0ed80620038e	2577d100-73c8-4579-9de2-4e76818a027e	2	2026-01-29 03:49:50.545065+00
f16f8d12-320d-416b-90d0-cf9828fb3a05	c7d4a12b-47a4-498d-baf0-1ce0a0212bb2	2	2026-01-29 03:49:50.545065+00
77e4b012-0f1c-4af3-a1a6-7ef3e1db3430	4db36368-05b1-4fd4-ac13-c8a8c06ba5f9	5	2026-01-29 03:49:50.545065+00
8705b85b-233d-4a50-9ed7-edaf10741e82	e49d2c9b-6744-497c-bb61-b58abcb6c7e5	7	2026-01-29 03:49:50.545065+00
bec9c941-6a5c-4d04-b4c1-d020c451ca18	e74c904e-6dcd-4536-af23-74401f842f22	1	2026-01-29 03:49:50.545065+00
24943659-a453-49b6-8a8a-3323f0000914	e74c904e-6dcd-4536-af23-74401f842f22	2	2026-01-29 03:49:50.545065+00
3964aae0-12c5-49ab-827a-cd267dd93683	e74c904e-6dcd-4536-af23-74401f842f22	3	2026-01-29 03:49:50.545065+00
ae83b370-d431-4567-8cdd-c83f1f6780c5	e74c904e-6dcd-4536-af23-74401f842f22	4	2026-01-29 03:49:50.545065+00
eaece191-84fe-4951-9a76-f4c36c61898f	e74c904e-6dcd-4536-af23-74401f842f22	5	2026-01-29 03:49:50.545065+00
79db7013-c987-49fb-a1f0-f5701d075470	e74c904e-6dcd-4536-af23-74401f842f22	6	2026-01-29 03:49:50.545065+00
\.


--
-- Data for Name: presenca_evento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."presenca_evento" ("id_chamada", "id_evento", "presenca", "justificativa", "created_at", "id_membro") FROM stdin;
468c5cdb-2f36-41d2-8ffc-1c3010c25f76	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:25.437205+00	03a18d33-f884-43a5-a579-162578daac5a
fb529ac9-dab6-4172-942b-4e42d6a1179b	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:32.047384+00	2577d100-73c8-4579-9de2-4e76818a027e
40082eb5-dd3c-4ee4-bd66-f8917775caf8	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:35.648566+00	e74c904e-6dcd-4536-af23-74401f842f22
a772e859-81e5-40d9-a671-54526365e64c	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:36.239956+00	b64a4caa-b645-414e-a213-d3076076922b
4969c818-9dd2-4164-9d25-9370b8fd2a2d	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:37.70896+00	414350c9-e858-4dee-85e4-a93c3a05bced
46dd9f42-c062-435a-843a-b2f31ce10bc0	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:38.389474+00	23d2d224-8f94-4e4f-ab13-7e8868e20611
9c02980a-7538-48f4-a719-965642c79e02	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:39.422054+00	96d801f5-58e6-444f-9416-d6817bb47042
acf46cf3-3b52-4bf1-b3bf-a5d3e8e5aa74	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:39.974783+00	dff6aff0-a4ac-4141-bda1-8e8ffa04cfff
131507a5-44f9-446a-bf88-5cf2cd1351cf	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:40.501247+00	a1d9f814-46e4-48d4-8262-b3fce5cb0fd6
08cebfd5-c88a-4f2e-b6dd-b8066f47f7be	dd9b7478-ec46-4c43-ae56-e078033cb2ab	justificado	Saiu do Grupo	2026-02-04 03:28:49.13913+00	e7fae8f4-1411-459b-af01-0eefdaa7e57c
1e9f3d41-6c79-4b86-9798-ec58a281eca7	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:51.629992+00	2ee9bbd2-f0e0-4e42-b7ca-a1eba002783b
89834e9e-5b42-4c36-8ba1-ac7cfdc4e27b	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:52.556465+00	51306dad-b8e0-46b4-aaa4-24510690a705
e970f113-babc-4873-b1ea-2a38dfaaabef	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:52.737228+00	4b543930-107b-4580-b00f-958769fa4400
80ccec72-8e35-43e8-8c70-406cac87eafb	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:53.984289+00	1563eb41-f8ad-4ff8-a141-778e4e73a288
f8ba8b67-246f-434b-89b0-20c499e5d9dd	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:54.680773+00	04696c14-57f5-4492-a09d-91a4bd2aea80
63362b1a-4902-4c5e-8bfb-4df988891e14	dd9b7478-ec46-4c43-ae56-e078033cb2ab	presente	\N	2026-02-04 03:28:55.351358+00	35be7e54-5d03-4e92-9304-abe4ca3885e8
a13ff425-52c5-4f6e-9661-f5ec679c8516	dd9b7478-ec46-4c43-ae56-e078033cb2ab	ausente	\N	2026-02-04 03:36:10.106357+00	24d79386-6eea-4478-8f2c-5611192b7a0c
\.


--
-- Data for Name: repertorio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."repertorio" ("id", "created_at", "id_culto", "id_musicas", "id_membros", "id_tons") FROM stdin;
\.


--
-- Data for Name: solicitacoes_membro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."solicitacoes_membro" ("id", "email", "nome", "aprovado", "created_at") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") FROM stdin;
public-assets	public-assets	\N	2026-02-01 03:57:24.298096+00	2026-02-01 03:57:24.298096+00	t	f	\N	\N	\N	STANDARD
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata") FROM stdin;
40a6a7f8-2d6c-417f-90b6-029257d7a049	public-assets	membros/.emptyFolderPlaceholder	\N	2026-02-01 03:58:25.709237+00	2026-02-01 03:58:25.709237+00	2026-02-01 03:58:25.709237+00	{"eTag": "\\"d41d8cd98f00b204e9800998ecf8427e\\"", "size": 0, "mimetype": "application/octet-stream", "cacheControl": "max-age=3600", "lastModified": "2026-02-01T03:58:25.710Z", "contentLength": 0, "httpStatusCode": 200}	1c5fcc27-cfca-4ebf-bc1d-8c1909bb1f8f	\N	{}
349300df-a838-446a-b8d9-b420d8b838c7	public-assets	limpeza/status_atual_1770225477667.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-04 17:18:07.213131+00	2026-02-04 17:18:07.213131+00	2026-02-04 17:18:07.213131+00	{"eTag": "\\"1a5f0ec36c2955c2b58603d4bd7a2e2e\\"", "size": 1634830, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-04T17:18:08.000Z", "contentLength": 1634830, "httpStatusCode": 200}	6a9a5f95-ee50-43c1-823e-c239ed1d8528	e74c904e-6dcd-4536-af23-74401f842f22	{}
3fdfee89-12b9-4b86-8156-e7f972fdac2b	public-assets	membros/aleane.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:55:33.712964+00	2026-02-02 05:55:33.712964+00	2026-02-02 05:55:33.712964+00	{"eTag": "\\"fd7d713931b4607cc23f5e76fea9ed4f\\"", "size": 1766402, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T05:55:34.000Z", "contentLength": 1766402, "httpStatusCode": 200}	e8eafdbd-37ce-4f9d-8cf9-9894f9c246b5	e74c904e-6dcd-4536-af23-74401f842f22	{}
705d789f-c530-4e49-a863-541e3ec274fd	public-assets	membros/ewerton.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:55:47.004836+00	2026-02-02 05:55:47.004836+00	2026-02-02 05:55:47.004836+00	{"eTag": "\\"01605e0bf852df17de2227b911ef4c45\\"", "size": 463578, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T05:55:47.000Z", "contentLength": 463578, "httpStatusCode": 200}	8cb96eb7-863e-461a-89a8-2fefde44715f	e74c904e-6dcd-4536-af23-74401f842f22	{}
7e9d6eba-495a-4114-b211-65aaa0a5d4e1	public-assets	membros/rosy.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:56:10.615608+00	2026-02-02 05:56:10.615608+00	2026-02-02 05:56:10.615608+00	{"eTag": "\\"01a76120f8acd7030ef17bf074c027c2\\"", "size": 397516, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T05:56:11.000Z", "contentLength": 397516, "httpStatusCode": 200}	483c6028-72df-49e2-bd6f-218d311971c1	e74c904e-6dcd-4536-af23-74401f842f22	{}
4c2b6b8a-b7ce-45f7-bee9-769ae2c66f35	public-assets	membros/felipe.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:57:02.641991+00	2026-02-02 05:57:02.641991+00	2026-02-02 05:57:02.641991+00	{"eTag": "\\"8cece0e7d5727b7c417986c7bdc84ada\\"", "size": 1011335, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T05:57:03.000Z", "contentLength": 1011335, "httpStatusCode": 200}	2220204c-2bbe-4b23-9c36-94fd275e6e21	e74c904e-6dcd-4536-af23-74401f842f22	{}
210ef908-daa4-423b-8d88-3ecea57a29ef	public-assets	membros/jesse.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:57:24.697863+00	2026-02-02 05:57:24.697863+00	2026-02-02 05:57:24.697863+00	{"eTag": "\\"9c763d3668faa38ac7580b6befe9caff\\"", "size": 713097, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T05:57:25.000Z", "contentLength": 713097, "httpStatusCode": 200}	86e3f482-6e83-498f-a866-8dc7c24bfdb9	e74c904e-6dcd-4536-af23-74401f842f22	{}
975d54f6-e1a9-4ed1-92ca-f139c510821a	public-assets	membros/lucas.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:57:59.909055+00	2026-02-02 05:57:59.909055+00	2026-02-02 05:57:59.909055+00	{"eTag": "\\"8727965f6b79538d5a872acb9bf1fe7d\\"", "size": 368422, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T05:58:00.000Z", "contentLength": 368422, "httpStatusCode": 200}	029f7639-4e61-4130-8827-c34dfddf8cb5	e74c904e-6dcd-4536-af23-74401f842f22	{}
d82b3409-6cd7-4902-87fb-62fdd9d40cb9	public-assets	membros/marcos.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:58:08.993483+00	2026-02-02 06:10:17.234549+00	2026-02-02 05:58:08.993483+00	{"eTag": "\\"65694d605e971918e05f67eee3792707\\"", "size": 576064, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:10:18.000Z", "contentLength": 576064, "httpStatusCode": 200}	b155d56f-a491-48ca-a899-9f6f5ee2e05e	e74c904e-6dcd-4536-af23-74401f842f22	{}
62b626be-3563-453c-9979-3f40dace81e0	public-assets	membros/isis.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:57:15.938949+00	2026-02-02 06:08:44.95553+00	2026-02-02 05:57:15.938949+00	{"eTag": "\\"09372f49661ccf138e4e85187996884d\\"", "size": 302123, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:08:45.000Z", "contentLength": 302123, "httpStatusCode": 200}	3f7467a5-64c6-483c-828b-96a288a4c796	e74c904e-6dcd-4536-af23-74401f842f22	{}
da2f329d-44e1-41af-aa55-52f041ebedf2	public-assets	membros/ana_clara.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:55:56.515495+00	2026-02-02 06:09:37.859735+00	2026-02-02 05:55:56.515495+00	{"eTag": "\\"8b966b8f3413041d02c5d8fc4125401a\\"", "size": 742822, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:09:38.000Z", "contentLength": 742822, "httpStatusCode": 200}	28363c15-eaa3-435b-954f-5f952d2d04f4	e74c904e-6dcd-4536-af23-74401f842f22	{}
31aa88e0-f0f8-4f1f-add1-ad9029216e60	public-assets	membros/marilei.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:58:16.601114+00	2026-02-02 06:10:27.966528+00	2026-02-02 05:58:16.601114+00	{"eTag": "\\"a01dddb0c9221ccc6ff81ef19689c0d3\\"", "size": 1274681, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:10:28.000Z", "contentLength": 1274681, "httpStatusCode": 200}	d5b3bae8-e20f-4d3a-a0ee-c4c5c64d46cb	e74c904e-6dcd-4536-af23-74401f842f22	{}
38a48e58-a5a3-41e1-91c1-1d27b173d5f8	public-assets	membros/mikeias.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:58:25.065065+00	2026-02-02 06:10:36.745466+00	2026-02-02 05:58:25.065065+00	{"eTag": "\\"fc8221402b680a3deb3f52b133543d21\\"", "size": 1058155, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:10:37.000Z", "contentLength": 1058155, "httpStatusCode": 200}	28eb4687-f159-4abd-8c78-1be9f8bf8974	e74c904e-6dcd-4536-af23-74401f842f22	{}
dd5f47d3-268e-49e5-b355-a32c49186ded	public-assets	membros/naira.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:58:35.333931+00	2026-02-02 05:58:35.333931+00	2026-02-02 05:58:35.333931+00	{"eTag": "\\"3d8477479014a67c8ef31bb0c43f045d\\"", "size": 748554, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T05:58:36.000Z", "contentLength": 748554, "httpStatusCode": 200}	3ea81b90-b919-4af1-a1ac-a9a1e7f6ece9	e74c904e-6dcd-4536-af23-74401f842f22	{}
a7a6fff9-da2e-46c9-adab-5daaf530e455	public-assets	membros/anne_gabrielly.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:06:26.506645+00	2026-02-02 06:06:26.506645+00	2026-02-02 06:06:26.506645+00	{"eTag": "\\"3cab30d0c9f471866827565f8723c961\\"", "size": 606729, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:06:27.000Z", "contentLength": 606729, "httpStatusCode": 200}	f7cf1e50-e3da-4b6e-8840-6e695e03881e	e74c904e-6dcd-4536-af23-74401f842f22	{}
293c111f-3b49-46d3-a4d6-e8667bd1cc10	public-assets	membros/jhordan.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-06 21:39:18.686973+00	2026-02-06 21:39:18.686973+00	2026-02-06 21:39:18.686973+00	{"eTag": "\\"f43e45ea816c340310a3b33e7deea23e\\"", "size": 2936610, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-06T21:39:19.000Z", "contentLength": 2936610, "httpStatusCode": 200}	05d1bbde-c073-4256-b73e-586098b3680c	e74c904e-6dcd-4536-af23-74401f842f22	{}
88282ded-c803-47a6-a488-d8b08ea8ea37	public-assets	membros/v__mesquita.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 05:58:48.023186+00	2026-02-02 05:58:48.023186+00	2026-02-02 05:58:48.023186+00	{"eTag": "\\"d61bcb6a9e2751a41fe7a29aaaae06c3\\"", "size": 5093228, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T05:58:48.000Z", "contentLength": 5093228, "httpStatusCode": 200}	a31f68eb-c4a5-4aa2-963b-91d5301295f1	e74c904e-6dcd-4536-af23-74401f842f22	{}
12d886db-3c6d-496e-8846-ed3d2cd7472f	public-assets	membros/gabriel.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:02:14.672108+00	2026-02-02 06:02:14.672108+00	2026-02-02 06:02:14.672108+00	{"eTag": "\\"12c74a0c6b88c9f4a3495c03f9caf5d3\\"", "size": 258862, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:02:15.000Z", "contentLength": 258862, "httpStatusCode": 200}	a69c97a8-b437-4ecf-80a1-d989224c403e	e74c904e-6dcd-4536-af23-74401f842f22	{}
bdc437c6-209e-4597-bd04-9cff588b7c9b	public-assets	membros/eduardo.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:08:59.968681+00	2026-02-02 06:09:21.908465+00	2026-02-02 06:08:59.968681+00	{"eTag": "\\"831ff9570bd29b9f0c76bf0b51c26dcb\\"", "size": 399604, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:09:22.000Z", "contentLength": 399604, "httpStatusCode": 200}	89a94c50-ea4d-4f94-a3e5-753e028d7b21	e74c904e-6dcd-4536-af23-74401f842f22	{}
a4996f60-649a-4001-86c9-96972a3b1781	public-assets	membros/dany.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:11:37.076712+00	2026-02-02 06:11:37.076712+00	2026-02-02 06:11:37.076712+00	{"eTag": "\\"d566c69f9b8cc1774059f76ec11fabaa\\"", "size": 402180, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:11:37.000Z", "contentLength": 402180, "httpStatusCode": 200}	68608718-a29f-4605-94ed-27dc1d70e181	e74c904e-6dcd-4536-af23-74401f842f22	{}
868160af-a39a-4359-9f38-9f7627cf4000	public-assets	membros/v__rodrigues.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:02:40.009049+00	2026-02-02 06:10:51.761449+00	2026-02-02 06:02:40.009049+00	{"eTag": "\\"1dab7d4b3196784a6b84b08eae6e7256\\"", "size": 28748, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:10:52.000Z", "contentLength": 28748, "httpStatusCode": 200}	ff2c7e2b-baf2-4f9e-be4b-284dbe319b06	e74c904e-6dcd-4536-af23-74401f842f22	{}
e848fdfc-8602-4734-b4b2-2197d08823ea	public-assets	membros/nayane.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:11:02.710021+00	2026-02-02 06:11:02.710021+00	2026-02-02 06:11:02.710021+00	{"eTag": "\\"1dab7d4b3196784a6b84b08eae6e7256\\"", "size": 28748, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:11:03.000Z", "contentLength": 28748, "httpStatusCode": 200}	2caca3de-3bdd-4377-8eb7-1e78d0c92f7e	e74c904e-6dcd-4536-af23-74401f842f22	{}
cdae4c90-a2bf-464a-8a89-56d48960e13a	public-assets	membros/veronica.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:11:13.229636+00	2026-02-02 06:11:13.229636+00	2026-02-02 06:11:13.229636+00	{"eTag": "\\"5584efdc15577ce61569e502a046cbd4\\"", "size": 61664, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:11:14.000Z", "contentLength": 61664, "httpStatusCode": 200}	d556284d-4f1c-4c90-90c1-7a0087de112b	e74c904e-6dcd-4536-af23-74401f842f22	{}
90ee6971-4e82-4818-98a3-fb2e335fabd9	public-assets	membros/cilene.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:11:24.996656+00	2026-02-02 06:11:24.996656+00	2026-02-02 06:11:24.996656+00	{"eTag": "\\"133f6b7e2971e62bf856ba81ef0034fa\\"", "size": 128709, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:11:25.000Z", "contentLength": 128709, "httpStatusCode": 200}	b6f9de4e-e889-4375-aaf2-8814f6668e9e	e74c904e-6dcd-4536-af23-74401f842f22	{}
b507619b-206d-4b54-9a55-4381b748af37	public-assets	membros/adjanio.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:11:48.264124+00	2026-02-02 06:11:48.264124+00	2026-02-02 06:11:48.264124+00	{"eTag": "\\"2c6e94aaf20d66610132b533ae100324\\"", "size": 57921, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:11:49.000Z", "contentLength": 57921, "httpStatusCode": 200}	f88de5d4-e36f-47d9-87b2-d87e55f37403	e74c904e-6dcd-4536-af23-74401f842f22	{}
3ae3651b-9463-4e02-9def-7026269c7427	public-assets	membros/wesley.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:12:10.194515+00	2026-02-02 06:12:10.194515+00	2026-02-02 06:12:10.194515+00	{"eTag": "\\"2c6e94aaf20d66610132b533ae100324\\"", "size": 57921, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:12:11.000Z", "contentLength": 57921, "httpStatusCode": 200}	027239f6-b96f-4dbb-ba2a-c3f978440486	e74c904e-6dcd-4536-af23-74401f842f22	{}
e34d2e94-7a10-42e1-aa14-67305b10d306	public-assets	membros/yokennan.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:12:21.321229+00	2026-02-02 06:12:21.321229+00	2026-02-02 06:12:21.321229+00	{"eTag": "\\"2c6e94aaf20d66610132b533ae100324\\"", "size": 57921, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:12:22.000Z", "contentLength": 57921, "httpStatusCode": 200}	caad9f6e-bd2d-4a65-8678-7f3b52877f55	e74c904e-6dcd-4536-af23-74401f842f22	{}
36d02586-1b51-4785-9540-cdf52f503e74	public-assets	membros/kaka.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:12:30.784458+00	2026-02-02 06:12:30.784458+00	2026-02-02 06:12:30.784458+00	{"eTag": "\\"f8a3fda4a0b41a1ea64bd3350e09d380\\"", "size": 192841, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:12:31.000Z", "contentLength": 192841, "httpStatusCode": 200}	2910da12-72df-4afe-b09a-dfc26ed866bd	e74c904e-6dcd-4536-af23-74401f842f22	{}
edda424b-fd31-43f7-b8f8-c07f99386ed7	public-assets	membros/guilherme.png	e74c904e-6dcd-4536-af23-74401f842f22	2026-02-02 06:12:47.258904+00	2026-02-02 06:13:21.140824+00	2026-02-02 06:12:47.258904+00	{"eTag": "\\"f4cc64a874dccaeaf025391895976160\\"", "size": 1094265, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-02T06:13:22.000Z", "contentLength": 1094265, "httpStatusCode": 200}	88f5ac88-7e7e-47ce-816f-2e22a5bd7cd0	e74c904e-6dcd-4536-af23-74401f842f22	{}
d2412b49-579e-422e-9719-df93df4a05fc	public-assets	logo/Cloud_Worship.png	\N	2026-02-04 03:40:04.810098+00	2026-02-04 03:40:23.091357+00	2026-02-04 03:40:04.810098+00	{"eTag": "\\"f812719b24a27f993ea75b16cd0df438\\"", "size": 17467, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-02-04T03:40:24.000Z", "contentLength": 17467, "httpStatusCode": 200}	f72c7f24-4e76-4e47-b880-01ef3bcecd10	\N	\N
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 116, true);


--
-- Name: aviso_geral_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."aviso_geral_id_seq"', 5, true);


--
-- Name: funcao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."funcao_id_seq"', 8, true);


--
-- Name: limpeza_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."limpeza_id_seq"', 5, true);


--
-- Name: tons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."tons_id_seq"', 36, true);


--
-- PostgreSQL database dump complete
--

-- \unrestrict EJ2anmLKwjs83Ins2TVm0tLMg36ltL0zgvfImsvDbdJH1BQe9hIC3BRhmKUcLbL

RESET ALL;
