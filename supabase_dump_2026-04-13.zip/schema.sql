


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";






CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE TYPE "public"."estilo_musica" AS ENUM (
    'Adoração',
    'Celebração'
);


ALTER TYPE "public"."estilo_musica" OWNER TO "postgres";


CREATE TYPE "public"."genero_membros" AS ENUM (
    'Homem',
    'Mulher'
);


ALTER TYPE "public"."genero_membros" OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."aprovar_membro"("user_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  -- 1. Insere na tabela oficial de membros
  INSERT INTO public.membros (id, nome, email)
  SELECT id, nome, email 
  FROM public.solicitacoes_membro 
  WHERE id = user_id;

  -- 2. Remove da lista de aprovação
  DELETE FROM public.solicitacoes_membro WHERE id = user_id;
END;
$$;


ALTER FUNCTION "public"."aprovar_membro"("user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."aprovar_membro"("user_id" "uuid", "lista_funcao_ids" bigint[]) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    f_id bigint;
BEGIN
    -- 1. Move o usuário para a tabela oficial de membros
    INSERT INTO public.membros (id, nome, email)
    SELECT id, nome, email 
    FROM public.solicitacoes_membro 
    WHERE id = user_id;

    -- 2. Vincula cada função selecionada ao membro
    FOREACH f_id IN ARRAY lista_funcao_ids
    LOOP
        INSERT INTO public.membro_funcoes (membro_id, funcao_id)
        VALUES (user_id, f_id);
    END LOOP;

    -- 3. Remove da fila de espera
    DELETE FROM public.solicitacoes_membro WHERE id = user_id;
END;
$$;


ALTER FUNCTION "public"."aprovar_membro"("user_id" "uuid", "lista_funcao_ids" bigint[]) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."formatar_musica_cantor"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  -- 1. Abrevia "Ministério" ou "Ministerio" (com ou sem acento/maiúscula) para "Min."
  NEW.cantor := regexp_replace(NEW.cantor, '(?i)Minist[eé]rio', 'Min.', 'g');

  -- 2. Aplica o Title Case (Iniciais Maiúsculas)
  NEW.musica := initcap(lower(NEW.musica));
  NEW.cantor := initcap(lower(NEW.cantor));

  -- 3. Limpa espaços extras
  NEW.musica := trim(regexp_replace(NEW.musica, '\s+', ' ', 'g'));
  NEW.cantor := trim(regexp_replace(NEW.cantor, '\s+', ' ', 'g'));

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."formatar_musica_cantor"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_user_display_names"() RETURNS TABLE("user_id" "uuid", "display_name" "text", "full_name" "text", "name" "text", "email" "text", "nome" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  -- Buscar usuários da tabela auth.users que têm correspondência na tabela membros
  RETURN QUERY
  SELECT 
    u.id as user_id,
    COALESCE(u.raw_user_meta_data->>'display_name', u.raw_user_meta_data->>'full_name', u.raw_user_meta_data->>'name') as display_name,
    u.raw_user_meta_data->>'full_name' as full_name,
    u.raw_user_meta_data->>'name' as name,
    u.email,
    m.nome
  FROM auth.users u
  INNER JOIN membros m ON u.id = m.id
  WHERE u.id IS NOT NULL
  ORDER BY u.email;
END;
$$;


ALTER FUNCTION "public"."get_user_display_names"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_new_user"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  INSERT INTO public.membros (id, nome, ativo)
  VALUES (new.id, new.raw_user_meta_data->>'full_name', true);
  RETURN new;
END;
$$;


ALTER FUNCTION "public"."handle_new_user"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_novo_cadastro"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  INSERT INTO public.solicitacoes_membro (id, email, nome)
  VALUES (
    NEW.id, 
    lower(NEW.email), -- Força o e-mail em minúsculo
    initcap(lower(split_part(NEW.email, '@', 1))) -- Nome inicial sugerido
  );
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."handle_novo_cadastro"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."aviso_geral" (
    "id" bigint NOT NULL,
    "created_at" "date" DEFAULT "now"() NOT NULL,
    "id_membro" "uuid",
    "texto" "text"
);


ALTER TABLE "public"."aviso_geral" OWNER TO "postgres";


ALTER TABLE "public"."aviso_geral" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."aviso_geral_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."avisos_cultos" (
    "id_lembrete" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "id_membros" "uuid",
    "id_cultos" "uuid",
    "info" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."avisos_cultos" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."cultos" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "data_culto" "date" NOT NULL,
    "id_nome_cultos" "uuid",
    "horario" time without time zone DEFAULT '19:00:00'::time without time zone
);


ALTER TABLE "public"."cultos" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."escalas" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "data_ensaio" "date",
    "horario_ensaio" time without time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "id_culto" "uuid",
    "id_membros" "uuid",
    "id_funcao" bigint
);


ALTER TABLE "public"."escalas" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."eventos" (
    "id_evento" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "data_evento" "date",
    "tema" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "horario_evento" time without time zone
);


ALTER TABLE "public"."eventos" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."funcao" (
    "id" bigint NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "nome_funcao" "text"
);


ALTER TABLE "public"."funcao" OWNER TO "postgres";


ALTER TABLE "public"."funcao" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."funcao_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."historico_musicas" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "id_membros" "uuid",
    "id_tons" bigint,
    "id_musica" "uuid"
);


ALTER TABLE "public"."historico_musicas" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."limpeza" (
    "id" bigint NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "foto" "text"
);


ALTER TABLE "public"."limpeza" OWNER TO "postgres";


ALTER TABLE "public"."limpeza" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."limpeza_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."membros" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "nome" "text",
    "telefone" "text",
    "ativo" boolean DEFAULT true,
    "genero" "public"."genero_membros",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "foto" json,
    "perfil" "text",
    "email" "text",
    "data_nasc" "date"
);


ALTER TABLE "public"."membros" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."membros_funcoes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "id_membro" "uuid",
    "id_funcao" bigint,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."membros_funcoes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."musicas" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "estilo" "public"."estilo_musica",
    "musica" "text",
    "cantor" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "id_temas" "uuid"
);


ALTER TABLE "public"."musicas" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."nome_cultos" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "nome_culto" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."nome_cultos" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."presenca_evento" (
    "id_chamada" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "id_evento" "uuid",
    "presenca" "text",
    "justificativa" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "id_membro" "uuid"
);


ALTER TABLE "public"."presenca_evento" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."repertorio" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "id_culto" "uuid",
    "id_musicas" "uuid",
    "id_membros" "uuid",
    "id_tons" bigint
);


ALTER TABLE "public"."repertorio" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."solicitacoes_membro" (
    "id" "uuid" NOT NULL,
    "email" "text" NOT NULL,
    "nome" "text",
    "aprovado" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."solicitacoes_membro" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."temas" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "nome_tema" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."temas" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."tons" (
    "id" bigint NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "nome_tons" "text",
    "descricao_tons" "text"
);


ALTER TABLE "public"."tons" OWNER TO "postgres";


ALTER TABLE "public"."tons" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."tons_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



ALTER TABLE ONLY "public"."aviso_geral"
    ADD CONSTRAINT "aviso_geral_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."eventos"
    ADD CONSTRAINT "consagracao_pkey" PRIMARY KEY ("id_evento");



ALTER TABLE ONLY "public"."escalas"
    ADD CONSTRAINT "escalas_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."cultos"
    ADD CONSTRAINT "eventos_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."funcao"
    ADD CONSTRAINT "funcao_nome_funcao_key" UNIQUE ("nome_funcao");



ALTER TABLE ONLY "public"."funcao"
    ADD CONSTRAINT "funcao_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."historico_musicas"
    ADD CONSTRAINT "historico_musicas_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."avisos_cultos"
    ADD CONSTRAINT "lembretes_pkey" PRIMARY KEY ("id_lembrete");



ALTER TABLE ONLY "public"."limpeza"
    ADD CONSTRAINT "limpeza_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."nome_cultos"
    ADD CONSTRAINT "lookup_nome_cultos_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."temas"
    ADD CONSTRAINT "lookup_temas_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."membros"
    ADD CONSTRAINT "membros_email_key" UNIQUE ("email");



ALTER TABLE ONLY "public"."membros_funcoes"
    ADD CONSTRAINT "membros_funcoes_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."membros_funcoes"
    ADD CONSTRAINT "membros_funcoes_unique" UNIQUE ("id_membro", "id_funcao");



ALTER TABLE ONLY "public"."membros"
    ADD CONSTRAINT "membros_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."musicas"
    ADD CONSTRAINT "musicas_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."presenca_evento"
    ADD CONSTRAINT "presenca_evento_pkey" PRIMARY KEY ("id_chamada");



ALTER TABLE ONLY "public"."repertorio"
    ADD CONSTRAINT "repertorio_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."solicitacoes_membro"
    ADD CONSTRAINT "solicitacoes_membro_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."tons"
    ADD CONSTRAINT "tons_pkey" PRIMARY KEY ("id");



CREATE INDEX "idx_escalas_id_culto" ON "public"."escalas" USING "btree" ("id_culto");



CREATE INDEX "idx_repertorio_id_culto" ON "public"."repertorio" USING "btree" ("id_culto");



CREATE OR REPLACE TRIGGER "tr_formatar_musica_antes_de_inserir" BEFORE INSERT OR UPDATE ON "public"."musicas" FOR EACH ROW EXECUTE FUNCTION "public"."formatar_musica_cantor"();



ALTER TABLE ONLY "public"."aviso_geral"
    ADD CONSTRAINT "aviso_geral_id_membro_fkey" FOREIGN KEY ("id_membro") REFERENCES "public"."membros"("id");



ALTER TABLE ONLY "public"."avisos_cultos"
    ADD CONSTRAINT "avisos_cultos_id_cultos_fkey" FOREIGN KEY ("id_cultos") REFERENCES "public"."cultos"("id");



ALTER TABLE ONLY "public"."avisos_cultos"
    ADD CONSTRAINT "avisos_cultos_id_membros_fkey" FOREIGN KEY ("id_membros") REFERENCES "public"."membros"("id");



ALTER TABLE ONLY "public"."cultos"
    ADD CONSTRAINT "cultos_id_nome_cultos_fkey" FOREIGN KEY ("id_nome_cultos") REFERENCES "public"."nome_cultos"("id");



ALTER TABLE ONLY "public"."escalas"
    ADD CONSTRAINT "escalas_id_evento_fkey" FOREIGN KEY ("id_culto") REFERENCES "public"."cultos"("id");



ALTER TABLE ONLY "public"."escalas"
    ADD CONSTRAINT "escalas_id_funcao_fkey" FOREIGN KEY ("id_funcao") REFERENCES "public"."funcao"("id");



ALTER TABLE ONLY "public"."escalas"
    ADD CONSTRAINT "escalas_id_membros_fkey" FOREIGN KEY ("id_membros") REFERENCES "public"."membros"("id") ON UPDATE CASCADE;



ALTER TABLE ONLY "public"."presenca_evento"
    ADD CONSTRAINT "fk_presenca_membros" FOREIGN KEY ("id_membro") REFERENCES "public"."membros"("id");



ALTER TABLE ONLY "public"."historico_musicas"
    ADD CONSTRAINT "historico_musicas_id_membros_fkey" FOREIGN KEY ("id_membros") REFERENCES "public"."membros"("id") ON UPDATE CASCADE;



ALTER TABLE ONLY "public"."historico_musicas"
    ADD CONSTRAINT "historico_musicas_id_musica_fkey" FOREIGN KEY ("id_musica") REFERENCES "public"."musicas"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."historico_musicas"
    ADD CONSTRAINT "historico_musicas_id_tons_fkey" FOREIGN KEY ("id_tons") REFERENCES "public"."tons"("id");



ALTER TABLE ONLY "public"."membros_funcoes"
    ADD CONSTRAINT "membros_funcoes_id_funcao_fkey" FOREIGN KEY ("id_funcao") REFERENCES "public"."funcao"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."membros_funcoes"
    ADD CONSTRAINT "membros_funcoes_id_membro_fkey" FOREIGN KEY ("id_membro") REFERENCES "public"."membros"("id") ON UPDATE CASCADE;



ALTER TABLE ONLY "public"."musicas"
    ADD CONSTRAINT "musicas_id_temas_fkey" FOREIGN KEY ("id_temas") REFERENCES "public"."temas"("id");



ALTER TABLE ONLY "public"."presenca_evento"
    ADD CONSTRAINT "presenca_consagracao_id_evento_fkey" FOREIGN KEY ("id_evento") REFERENCES "public"."eventos"("id_evento");



ALTER TABLE ONLY "public"."repertorio"
    ADD CONSTRAINT "repertorio_id_evento_fkey" FOREIGN KEY ("id_culto") REFERENCES "public"."cultos"("id");



ALTER TABLE ONLY "public"."repertorio"
    ADD CONSTRAINT "repertorio_id_membros_fkey" FOREIGN KEY ("id_membros") REFERENCES "public"."membros"("id") ON UPDATE CASCADE;



ALTER TABLE ONLY "public"."repertorio"
    ADD CONSTRAINT "repertorio_id_musicas_fkey" FOREIGN KEY ("id_musicas") REFERENCES "public"."musicas"("id");



ALTER TABLE ONLY "public"."repertorio"
    ADD CONSTRAINT "repertorio_id_tons_fkey" FOREIGN KEY ("id_tons") REFERENCES "public"."tons"("id");



ALTER TABLE ONLY "public"."solicitacoes_membro"
    ADD CONSTRAINT "solicitacoes_membro_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id");



CREATE POLICY "Admins e lideres controle total" ON "public"."cultos" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."membros"
  WHERE (("membros"."id" = "auth"."uid"()) AND ("lower"("membros"."perfil") = ANY (ARRAY['admin'::"text", 'lider'::"text"])))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."membros"
  WHERE (("membros"."id" = "auth"."uid"()) AND ("lower"("membros"."perfil") = ANY (ARRAY['admin'::"text", 'lider'::"text"]))))));



CREATE POLICY "Anônimos podem criar solicitacoes_membro" ON "public"."solicitacoes_membro" FOR INSERT WITH CHECK (("auth"."role"() = 'anon'::"text"));



CREATE POLICY "Dono, Lider e Admin podem editar perfis" ON "public"."membros" FOR UPDATE USING ((("auth"."uid"() = "id") OR (EXISTS ( SELECT 1
   FROM "public"."membros" "membros_1"
  WHERE (("membros_1"."id" = "auth"."uid"()) AND (("membros_1"."perfil" = 'lider'::"text") OR ("membros_1"."perfil" = 'admin'::"text")))))));



CREATE POLICY "Todos podem ver solicitacoes_membro" ON "public"."solicitacoes_membro" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Users can delete eventos" ON "public"."eventos" FOR DELETE USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Users can delete presencas" ON "public"."presenca_evento" FOR DELETE USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Users can insert eventos" ON "public"."eventos" FOR INSERT WITH CHECK (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Users can insert presencas" ON "public"."presenca_evento" FOR INSERT WITH CHECK (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Users can update eventos" ON "public"."eventos" FOR UPDATE USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Users can update presencas" ON "public"."presenca_evento" FOR UPDATE USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Users can view eventos" ON "public"."eventos" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Users can view presencas" ON "public"."presenca_evento" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem criar aviso_geral" ON "public"."aviso_geral" FOR INSERT WITH CHECK (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem criar presenca_consagracao" ON "public"."presenca_evento" FOR INSERT WITH CHECK (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver aviso_geral" ON "public"."aviso_geral" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver cultos" ON "public"."cultos" FOR SELECT TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver eventos" ON "public"."eventos" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver funcoes" ON "public"."funcao" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver historico_musicas" ON "public"."historico_musicas" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver membros" ON "public"."membros" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver membros_funcoes" ON "public"."membros_funcoes" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver musicas" ON "public"."musicas" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver nome_cultos" ON "public"."nome_cultos" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver presenca_consagracao" ON "public"."presenca_evento" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver temas" ON "public"."temas" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários autenticados podem ver tons" ON "public"."tons" FOR SELECT USING (("auth"."role"() = 'authenticated'::"text"));



CREATE POLICY "Usuários podem editar próprio perfil" ON "public"."membros" FOR UPDATE USING ((("auth"."uid"())::"text" = ("id")::"text"));



ALTER TABLE "public"."aviso_geral" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."avisos_cultos" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "avisos_cultos_authenticated_users_policy" ON "public"."avisos_cultos" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));



ALTER TABLE "public"."cultos" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."escalas" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "escalas_rls_policy" ON "public"."escalas" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));



ALTER TABLE "public"."eventos" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."funcao" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."historico_musicas" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."limpeza" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "limpeza_admin_lider_full" ON "public"."limpeza" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."membros"
  WHERE (("membros"."id" = "auth"."uid"()) AND ("lower"("membros"."perfil") = ANY (ARRAY['admin'::"text", 'lider'::"text"])))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."membros"
  WHERE (("membros"."id" = "auth"."uid"()) AND ("lower"("membros"."perfil") = ANY (ARRAY['admin'::"text", 'lider'::"text"]))))));



CREATE POLICY "limpeza_read_all" ON "public"."limpeza" FOR SELECT USING (true);



ALTER TABLE "public"."membros" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."membros_funcoes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."musicas" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."nome_cultos" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."presenca_evento" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."repertorio" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "repertorio_authenticated_users_policy" ON "public"."repertorio" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));



ALTER TABLE "public"."solicitacoes_membro" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."temas" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."tons" ENABLE ROW LEVEL SECURITY;




ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";






ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."avisos_cultos";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."cultos";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."escalas";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."historico_musicas";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."membros";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."musicas";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."repertorio";



GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";

























































































































































GRANT ALL ON FUNCTION "public"."aprovar_membro"("user_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."aprovar_membro"("user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."aprovar_membro"("user_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."aprovar_membro"("user_id" "uuid", "lista_funcao_ids" bigint[]) TO "anon";
GRANT ALL ON FUNCTION "public"."aprovar_membro"("user_id" "uuid", "lista_funcao_ids" bigint[]) TO "authenticated";
GRANT ALL ON FUNCTION "public"."aprovar_membro"("user_id" "uuid", "lista_funcao_ids" bigint[]) TO "service_role";



GRANT ALL ON FUNCTION "public"."formatar_musica_cantor"() TO "anon";
GRANT ALL ON FUNCTION "public"."formatar_musica_cantor"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."formatar_musica_cantor"() TO "service_role";



GRANT ALL ON FUNCTION "public"."get_user_display_names"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_user_display_names"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_user_display_names"() TO "service_role";



GRANT ALL ON FUNCTION "public"."handle_new_user"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_new_user"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_new_user"() TO "service_role";



GRANT ALL ON FUNCTION "public"."handle_novo_cadastro"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_novo_cadastro"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_novo_cadastro"() TO "service_role";


















GRANT ALL ON TABLE "public"."aviso_geral" TO "anon";
GRANT ALL ON TABLE "public"."aviso_geral" TO "authenticated";
GRANT ALL ON TABLE "public"."aviso_geral" TO "service_role";



GRANT ALL ON SEQUENCE "public"."aviso_geral_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."aviso_geral_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."aviso_geral_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."avisos_cultos" TO "anon";
GRANT ALL ON TABLE "public"."avisos_cultos" TO "authenticated";
GRANT ALL ON TABLE "public"."avisos_cultos" TO "service_role";



GRANT ALL ON TABLE "public"."cultos" TO "anon";
GRANT ALL ON TABLE "public"."cultos" TO "authenticated";
GRANT ALL ON TABLE "public"."cultos" TO "service_role";



GRANT ALL ON TABLE "public"."escalas" TO "anon";
GRANT ALL ON TABLE "public"."escalas" TO "authenticated";
GRANT ALL ON TABLE "public"."escalas" TO "service_role";



GRANT ALL ON TABLE "public"."eventos" TO "anon";
GRANT ALL ON TABLE "public"."eventos" TO "authenticated";
GRANT ALL ON TABLE "public"."eventos" TO "service_role";



GRANT ALL ON TABLE "public"."funcao" TO "anon";
GRANT ALL ON TABLE "public"."funcao" TO "authenticated";
GRANT ALL ON TABLE "public"."funcao" TO "service_role";



GRANT ALL ON SEQUENCE "public"."funcao_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."funcao_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."funcao_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."historico_musicas" TO "anon";
GRANT ALL ON TABLE "public"."historico_musicas" TO "authenticated";
GRANT ALL ON TABLE "public"."historico_musicas" TO "service_role";



GRANT ALL ON TABLE "public"."limpeza" TO "anon";
GRANT ALL ON TABLE "public"."limpeza" TO "authenticated";
GRANT ALL ON TABLE "public"."limpeza" TO "service_role";



GRANT ALL ON SEQUENCE "public"."limpeza_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."limpeza_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."limpeza_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."membros" TO "anon";
GRANT ALL ON TABLE "public"."membros" TO "authenticated";
GRANT ALL ON TABLE "public"."membros" TO "service_role";



GRANT ALL ON TABLE "public"."membros_funcoes" TO "anon";
GRANT ALL ON TABLE "public"."membros_funcoes" TO "authenticated";
GRANT ALL ON TABLE "public"."membros_funcoes" TO "service_role";



GRANT ALL ON TABLE "public"."musicas" TO "anon";
GRANT ALL ON TABLE "public"."musicas" TO "authenticated";
GRANT ALL ON TABLE "public"."musicas" TO "service_role";



GRANT ALL ON TABLE "public"."nome_cultos" TO "anon";
GRANT ALL ON TABLE "public"."nome_cultos" TO "authenticated";
GRANT ALL ON TABLE "public"."nome_cultos" TO "service_role";



GRANT ALL ON TABLE "public"."presenca_evento" TO "anon";
GRANT ALL ON TABLE "public"."presenca_evento" TO "authenticated";
GRANT ALL ON TABLE "public"."presenca_evento" TO "service_role";



GRANT ALL ON TABLE "public"."repertorio" TO "anon";
GRANT ALL ON TABLE "public"."repertorio" TO "authenticated";
GRANT ALL ON TABLE "public"."repertorio" TO "service_role";



GRANT ALL ON TABLE "public"."solicitacoes_membro" TO "anon";
GRANT ALL ON TABLE "public"."solicitacoes_membro" TO "authenticated";
GRANT ALL ON TABLE "public"."solicitacoes_membro" TO "service_role";



GRANT ALL ON TABLE "public"."temas" TO "anon";
GRANT ALL ON TABLE "public"."temas" TO "authenticated";
GRANT ALL ON TABLE "public"."temas" TO "service_role";



GRANT ALL ON TABLE "public"."tons" TO "anon";
GRANT ALL ON TABLE "public"."tons" TO "authenticated";
GRANT ALL ON TABLE "public"."tons" TO "service_role";



GRANT ALL ON SEQUENCE "public"."tons_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."tons_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."tons_id_seq" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";































